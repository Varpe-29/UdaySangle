// test/auth.e2e-spec.ts
import { Test, TestingModule } from '@nestjs/testing';
import { INestApplication, ValidationPipe } from '@nestjs/common';
import * as request from 'supertest';
import { AppModule } from '../src/app.module';
import { PrismaService } from '../src/prisma/prisma.service';

describe('Auth (e2e)', () => {
  let app: INestApplication;
  let prisma: PrismaService;

  beforeAll(async () => {
    const moduleFixture: TestingModule = await Test.createTestingModule({
      imports: [AppModule],
    }).compile();

    app = moduleFixture.createNestApplication();
    app.useGlobalPipes(new ValidationPipe({ whitelist: true, transform: true }));
    app.setGlobalPrefix('api');
    app.enableVersioning();

    prisma = moduleFixture.get<PrismaService>(PrismaService);
    await app.init();
  });

  afterAll(async () => {
    await app.close();
  });

  // ── Health Check ──────────────────────────────────────────
  describe('GET /health', () => {
    it('should return 200 with status ok', () => {
      return request(app.getHttpServer())
        .get('/health')
        .expect(200)
        .expect((res) => {
          expect(res.body.status).toBe('ok');
        });
    });
  });

  // ── Login ──────────────────────────────────────────────────
  describe('POST /api/v1/auth/login', () => {
    it('should reject missing credentials (400)', () => {
      return request(app.getHttpServer())
        .post('/api/v1/auth/login')
        .send({})
        .expect(400);
    });

    it('should reject invalid credentials (401)', () => {
      return request(app.getHttpServer())
        .post('/api/v1/auth/login')
        .send({ username: 'notauser', password: 'wrongpassword' })
        .expect(401);
    });

    it('should return 401 for wrong password', () => {
      return request(app.getHttpServer())
        .post('/api/v1/auth/login')
        .send({ username: 'admin', password: 'completely-wrong' })
        .expect(401);
    });
  });

  // ── Protected Route ────────────────────────────────────────
  describe('GET /api/v1/auth/me', () => {
    it('should return 401 without token', () => {
      return request(app.getHttpServer())
        .get('/api/v1/auth/me')
        .expect(401);
    });
  });

  // ── Public Routes ──────────────────────────────────────────
  describe('GET /api/v1/complaints/public', () => {
    it('should return 200 without auth', () => {
      return request(app.getHttpServer())
        .get('/api/v1/complaints/public')
        .expect(200);
    });
  });

  describe('GET /api/v1/notices', () => {
    it('should return 200 without auth', () => {
      return request(app.getHttpServer())
        .get('/api/v1/notices')
        .expect(200);
    });
  });

  // ── Rate Limiting ──────────────────────────────────────────
  describe('POST /api/v1/auth/login rate limit', () => {
    it('should return 429 after 5 rapid requests', async () => {
      const requests = Array.from({ length: 6 }, () =>
        request(app.getHttpServer())
          .post('/api/v1/auth/login')
          .send({ username: 'x', password: 'x' }),
      );
      const responses = await Promise.all(requests);
      const tooMany = responses.some((r) => r.status === 429);
      expect(tooMany).toBe(true);
    });
  });
});
