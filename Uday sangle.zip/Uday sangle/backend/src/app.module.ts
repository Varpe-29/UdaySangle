// src/app.module.ts
import { Module, MiddlewareConsumer, NestModule } from '@nestjs/common';
import { ConfigModule, ConfigService } from '@nestjs/config';
import { ThrottlerModule } from '@nestjs/throttler';
import { ScheduleModule } from '@nestjs/schedule';
import { AuthModule } from './modules/auth/auth.module';
import { UsersModule } from './modules/users/users.module';
import { ComplaintsModule } from './modules/complaints/complaints.module';
import { AppointmentsModule } from './modules/appointments/appointments.module';
import { NoticesModule } from './modules/notices/notices.module';
import { LettersModule } from './modules/letters/letters.module';
import { AdminModule } from './modules/admin/admin.module';
import { PrismaModule } from './prisma/prisma.module';
import { validationSchema } from './config/env.validation';
import { RequestLoggerMiddleware } from './common/middleware/request-logger.middleware';
import { SecurityMiddleware } from './common/middleware/security.middleware';
import { HealthModule } from './modules/health/health.module';

@Module({
  imports: [
    // ── Config ──────────────────────────────────────────────
    ConfigModule.forRoot({
      isGlobal: true,
      envFilePath: ['.env.local', '.env'],
      validationSchema,
      validationOptions: { abortEarly: false },
    }),

    // ── Rate Limiting (global brute-force protection) ────────
    ThrottlerModule.forRootAsync({
      inject: [ConfigService],
      useFactory: (config: ConfigService) => [
        {
          ttl: config.get<number>('THROTTLE_TTL', 60000),
          limit: config.get<number>('THROTTLE_LIMIT', 60),
        },
      ],
    }),

    // ── Scheduled Jobs ────────────────────────────────────────
    ScheduleModule.forRoot(),

    // ── Core modules ─────────────────────────────────────────
    PrismaModule,
    HealthModule,
    AuthModule,
    UsersModule,
    ComplaintsModule,
    AppointmentsModule,
    NoticesModule,
    LettersModule,
    AdminModule,
  ],
})
export class AppModule implements NestModule {
  configure(consumer: MiddlewareConsumer) {
    consumer
      .apply(RequestLoggerMiddleware, SecurityMiddleware)
      .forRoutes('*');
  }
}
