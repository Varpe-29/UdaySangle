// src/config/multer.config.ts
import { memoryStorage } from 'multer';
import { BadRequestException } from '@nestjs/common';

const ALLOWED_MIME_TYPES = [
  'image/jpeg', 'image/png', 'image/gif', 'image/webp',
  'application/pdf',
  'video/mp4', 'video/webm',
];

export const multerConfig = {
  storage: memoryStorage(),
  limits: {
    fileSize: 20 * 1024 * 1024, // 20MB
    files: 5,
  },
  fileFilter: (_req: any, file: Express.Multer.File, callback: any) => {
    if (ALLOWED_MIME_TYPES.includes(file.mimetype)) {
      callback(null, true);
    } else {
      callback(
        new BadRequestException(`File type ${file.mimetype} not allowed`),
        false,
      );
    }
  },
};
