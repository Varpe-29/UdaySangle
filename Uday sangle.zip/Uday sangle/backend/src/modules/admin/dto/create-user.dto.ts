// src/modules/admin/dto/create-user.dto.ts
import { IsString, IsNotEmpty, IsEmail, IsOptional, IsEnum, MinLength, MaxLength } from 'class-validator';
import { ApiProperty } from '@nestjs/swagger';
import { Transform } from 'class-transformer';

export class CreateUserDto {
  @ApiProperty({ example: 'newstaff' })
  @IsString() @IsNotEmpty() @MaxLength(50)
  @Transform(({ value }) => value?.trim().toLowerCase())
  username: string;

  @ApiProperty({ example: 'staff@office.com', required: false })
  @IsOptional() @IsEmail()
  email?: string;

  @ApiProperty({ example: 'SecurePass123!', minLength: 8 })
  @IsString() @IsNotEmpty() @MinLength(8) @MaxLength(100)
  password: string;

  @ApiProperty({ enum: ['SUPER_ADMIN', 'MAIN_ADMIN', 'STAFF_ADMIN'], default: 'STAFF_ADMIN' })
  @IsEnum(['SUPER_ADMIN', 'MAIN_ADMIN', 'STAFF_ADMIN'])
  role: string = 'STAFF_ADMIN';
}
