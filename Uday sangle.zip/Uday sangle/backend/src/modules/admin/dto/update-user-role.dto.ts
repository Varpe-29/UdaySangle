// src/modules/admin/dto/update-user-role.dto.ts
import { IsEnum } from 'class-validator';
import { ApiProperty } from '@nestjs/swagger';

export class UpdateUserRoleDto {
  @ApiProperty({ enum: ['SUPER_ADMIN', 'MAIN_ADMIN', 'STAFF_ADMIN'] })
  @IsEnum(['SUPER_ADMIN', 'MAIN_ADMIN', 'STAFF_ADMIN'])
  role: string;
}
