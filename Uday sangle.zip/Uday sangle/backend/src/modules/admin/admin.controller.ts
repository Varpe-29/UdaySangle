// src/modules/admin/admin.controller.ts
import {
  Controller, Get, Patch, Delete, Body, Param, Query,
  UseGuards, ParseUUIDPipe, Post,
} from '@nestjs/common';
import { ApiTags, ApiOperation, ApiBearerAuth } from '@nestjs/swagger';
import { JwtAuthGuard } from '../../common/guards/jwt-auth.guard';
import { RolesGuard } from '../../common/guards/roles.guard';
import { Roles } from '../../common/decorators/roles.decorator';
import { AdminService } from './admin.service';
import { CreateUserDto } from './dto/create-user.dto';
import { UpdateUserRoleDto } from './dto/update-user-role.dto';

@ApiTags('Admin')
@Controller({ path: 'admin', version: '1' })
@UseGuards(JwtAuthGuard, RolesGuard)
@Roles('SUPER_ADMIN', 'MAIN_ADMIN')
@ApiBearerAuth('access-token')
export class AdminController {
  constructor(private readonly adminService: AdminService) {}

  // ── Dashboard Analytics ───────────────────────────────────
  @Get('analytics')
  @ApiOperation({ summary: 'Get dashboard analytics' })
  async getAnalytics() {
    return this.adminService.getAnalytics();
  }

  // ── User Management ───────────────────────────────────────
  @Get('users')
  @ApiOperation({ summary: 'Get all users' })
  async getUsers(@Query('page') page = 1, @Query('limit') limit = 10, @Query('search') search?: string) {
    return this.adminService.getUsers({ page: +page, limit: +limit, search });
  }

  @Post('users')
  @Roles('SUPER_ADMIN')
  @ApiOperation({ summary: 'Create new admin user (Super Admin only)' })
  async createUser(@Body() dto: CreateUserDto) {
    return this.adminService.createUser(dto);
  }

  @Patch('users/:id/role')
  @Roles('SUPER_ADMIN')
  @ApiOperation({ summary: 'Update user role' })
  async updateRole(
    @Param('id', ParseUUIDPipe) id: string,
    @Body() dto: UpdateUserRoleDto,
  ) {
    return this.adminService.updateUserRole(id, dto.role);
  }

  @Patch('users/:id/toggle-lock')
  @ApiOperation({ summary: 'Lock or unlock user account' })
  async toggleLock(@Param('id', ParseUUIDPipe) id: string) {
    return this.adminService.toggleUserLock(id);
  }

  @Delete('users/:id')
  @Roles('SUPER_ADMIN')
  @ApiOperation({ summary: 'Soft delete user' })
  async deleteUser(@Param('id', ParseUUIDPipe) id: string) {
    return this.adminService.deleteUser(id);
  }

  // ── Logs ─────────────────────────────────────────────────
  @Get('activity-logs')
  @ApiOperation({ summary: 'Get activity logs' })
  async getActivityLogs(@Query('page') page = 1, @Query('limit') limit = 20) {
    return this.adminService.getActivityLogs({ page: +page, limit: +limit });
  }

  @Get('audit-logs')
  @ApiOperation({ summary: 'Get audit logs' })
  async getAuditLogs(@Query('page') page = 1, @Query('limit') limit = 20) {
    return this.adminService.getAuditLogs({ page: +page, limit: +limit });
  }

  // ── Sessions ─────────────────────────────────────────────
  @Get('sessions')
  @ApiOperation({ summary: 'Get active sessions' })
  async getSessions() {
    return this.adminService.getActiveSessions();
  }

  // ── Notifications ─────────────────────────────────────────
  @Get('notifications')
  @ApiOperation({ summary: 'Get admin notifications' })
  async getNotifications(@Query('userId') userId: string) {
    return this.adminService.getNotifications(userId);
  }
}
