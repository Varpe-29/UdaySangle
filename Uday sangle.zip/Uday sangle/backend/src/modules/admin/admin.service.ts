// src/modules/admin/admin.service.ts
import { Injectable, NotFoundException, ConflictException } from '@nestjs/common';
import { PrismaService } from '../../prisma/prisma.service';
import { CreateUserDto } from './dto/create-user.dto';
import * as bcrypt from 'bcrypt';
import { Role } from '@prisma/client';

@Injectable()
export class AdminService {
  constructor(private readonly prisma: PrismaService) {}

  // ── Analytics ─────────────────────────────────────────────

  async getAnalytics() {
    const now = new Date();
    const thisMonth = new Date(now.getFullYear(), now.getMonth(), 1);
    const lastMonth = new Date(now.getFullYear(), now.getMonth() - 1, 1);

    const [
      totalComplaints,
      pendingComplaints,
      doneComplaints,
      totalAppointments,
      pendingAppointments,
      confirmedAppointments,
      totalNotices,
      totalUsers,
      totalLetters,
      complaintsThisMonth,
      complaintsLastMonth,
      appointmentsThisMonth,
      recentActivity,
    ] = await Promise.all([
      this.prisma.complaint.count({ where: { deletedAt: null } }),
      this.prisma.complaint.count({ where: { status: 'PENDING', deletedAt: null } }),
      this.prisma.complaint.count({ where: { status: 'DONE', deletedAt: null } }),
      this.prisma.appointment.count({ where: { deletedAt: null } }),
      this.prisma.appointment.count({ where: { status: 'PENDING', deletedAt: null } }),
      this.prisma.appointment.count({ where: { status: 'CONFIRMED', deletedAt: null } }),
      this.prisma.notice.count({ where: { deletedAt: null } }),
      this.prisma.user.count({ where: { deletedAt: null } }),
      this.prisma.letter.count({ where: { deletedAt: null } }),
      this.prisma.complaint.count({ where: { createdAt: { gte: thisMonth }, deletedAt: null } }),
      this.prisma.complaint.count({ where: { createdAt: { gte: lastMonth, lt: thisMonth }, deletedAt: null } }),
      this.prisma.appointment.count({ where: { createdAt: { gte: thisMonth }, deletedAt: null } }),
      this.prisma.activityLog.findMany({
        take: 10,
        orderBy: { createdAt: 'desc' },
        include: { user: { select: { username: true, role: true } } },
      }),
    ]);

    // Monthly trend for last 6 months
    const months = [];
    for (let i = 5; i >= 0; i--) {
      const start = new Date(now.getFullYear(), now.getMonth() - i, 1);
      const end = new Date(now.getFullYear(), now.getMonth() - i + 1, 1);
      const [complaints, appointments] = await Promise.all([
        this.prisma.complaint.count({ where: { createdAt: { gte: start, lt: end }, deletedAt: null } }),
        this.prisma.appointment.count({ where: { createdAt: { gte: start, lt: end }, deletedAt: null } }),
      ]);
      months.push({
        month: start.toLocaleString('default', { month: 'short', year: '2-digit' }),
        complaints,
        appointments,
      });
    }

    return {
      overview: {
        totalComplaints,
        pendingComplaints,
        doneComplaints,
        totalAppointments,
        pendingAppointments,
        confirmedAppointments,
        totalNotices,
        totalUsers,
        totalLetters,
      },
      trends: {
        complaintsThisMonth,
        complaintsGrowth: complaintsLastMonth > 0
          ? Math.round(((complaintsThisMonth - complaintsLastMonth) / complaintsLastMonth) * 100)
          : 0,
        appointmentsThisMonth,
      },
      monthlyChart: months,
      recentActivity,
    };
  }

  // ── User Management ───────────────────────────────────────

  async getUsers({ page, limit, search }: { page: number; limit: number; search?: string }) {
    const skip = (page - 1) * limit;
    const where: any = { deletedAt: null };
    if (search) {
      where.OR = [
        { username: { contains: search, mode: 'insensitive' } },
        { email: { contains: search, mode: 'insensitive' } },
      ];
    }
    const [total, users] = await Promise.all([
      this.prisma.user.count({ where }),
      this.prisma.user.findMany({
        where,
        skip,
        take: limit,
        orderBy: { createdAt: 'desc' },
        select: {
          id: true, username: true, email: true, role: true,
          isActive: true, isLocked: true, lastLoginAt: true,
          lastLoginIp: true, createdAt: true,
        },
      }),
    ]);
    return { data: users, meta: { total, page, limit, totalPages: Math.ceil(total / limit) } };
  }

  async createUser(dto: CreateUserDto) {
    const existing = await this.prisma.user.findUnique({ where: { username: dto.username } });
    if (existing) throw new ConflictException('Username already taken');

    const passwordHash = await bcrypt.hash(dto.password, 12);
    const user = await this.prisma.user.create({
      data: {
        username: dto.username,
        email: dto.email,
        passwordHash,
        role: dto.role as Role,
      },
      select: { id: true, username: true, email: true, role: true, createdAt: true },
    });
    return user;
  }

  async updateUserRole(id: string, role: string) {
    const user = await this.prisma.user.findFirst({ where: { id, deletedAt: null } });
    if (!user) throw new NotFoundException('User not found');
    return this.prisma.user.update({
      where: { id },
      data: { role: role as Role },
      select: { id: true, username: true, role: true },
    });
  }

  async toggleUserLock(id: string) {
    const user = await this.prisma.user.findFirst({ where: { id, deletedAt: null } });
    if (!user) throw new NotFoundException('User not found');
    return this.prisma.user.update({
      where: { id },
      data: {
        isLocked: !user.isLocked,
        failedAttempts: !user.isLocked ? user.failedAttempts : 0,
        lockedUntil: !user.isLocked ? null : user.lockedUntil,
      },
      select: { id: true, username: true, isLocked: true },
    });
  }

  async deleteUser(id: string) {
    const user = await this.prisma.user.findFirst({ where: { id, deletedAt: null } });
    if (!user) throw new NotFoundException('User not found');
    await this.prisma.user.update({ where: { id }, data: { deletedAt: new Date(), isActive: false } });
    return { message: 'User deleted successfully' };
  }

  async getActivityLogs({ page, limit }: { page: number; limit: number }) {
    const skip = (page - 1) * limit;
    const [total, logs] = await Promise.all([
      this.prisma.activityLog.count(),
      this.prisma.activityLog.findMany({
        skip, take: limit, orderBy: { createdAt: 'desc' },
        include: { user: { select: { username: true, role: true } } },
      }),
    ]);
    return { data: logs, meta: { total, page, limit, totalPages: Math.ceil(total / limit) } };
  }

  async getAuditLogs({ page, limit }: { page: number; limit: number }) {
    const skip = (page - 1) * limit;
    const [total, logs] = await Promise.all([
      this.prisma.auditLog.count(),
      this.prisma.auditLog.findMany({
        skip, take: limit, orderBy: { createdAt: 'desc' },
        include: { user: { select: { username: true } } },
      }),
    ]);
    return { data: logs, meta: { total, page, limit, totalPages: Math.ceil(total / limit) } };
  }

  async getActiveSessions() {
    return this.prisma.session.findMany({
      where: { isActive: true, expiresAt: { gt: new Date() } },
      include: { user: { select: { username: true, role: true } } },
      orderBy: { createdAt: 'desc' },
    });
  }

  async getNotifications(userId: string) {
    return this.prisma.notification.findMany({
      where: { userId },
      orderBy: { createdAt: 'desc' },
      take: 50,
    });
  }
}
