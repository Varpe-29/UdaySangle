// src/modules/letters/letters.controller.ts
import {
  Controller, Get, Post, Delete, Body, Param, UseGuards,
  UseInterceptors, UploadedFiles, ParseUUIDPipe, HttpCode, HttpStatus,
} from '@nestjs/common';
import { FilesInterceptor } from '@nestjs/platform-express';
import { ApiTags, ApiOperation, ApiBearerAuth } from '@nestjs/swagger';
import { JwtAuthGuard } from '../../common/guards/jwt-auth.guard';
import { RolesGuard } from '../../common/guards/roles.guard';
import { Roles } from '../../common/decorators/roles.decorator';
import { CurrentUser } from '../../common/decorators/current-user.decorator';
import { LettersService } from './letters.service';
import { multerConfig } from '../../config/multer.config';

@ApiTags('Letters')
@Controller({ path: 'letters', version: '1' })
@UseGuards(JwtAuthGuard, RolesGuard)
@Roles('SUPER_ADMIN', 'MAIN_ADMIN', 'STAFF_ADMIN')
@ApiBearerAuth('access-token')
export class LettersController {
  constructor(private readonly service: LettersService) {}

  @Get()
  @ApiOperation({ summary: 'Get all letters' })
  async findAll() {
    return this.service.findAll();
  }

  @Post()
  @HttpCode(HttpStatus.CREATED)
  @UseInterceptors(FilesInterceptor('files', 5, multerConfig))
  @ApiOperation({ summary: 'Create letter' })
  async create(
    @Body() body: { title: string; content: string; recipient?: string },
    @UploadedFiles() files: Express.Multer.File[],
    @CurrentUser() user: any,
  ) {
    return this.service.create(body, files || [], user.username);
  }

  @Delete(':id')
  @Roles('SUPER_ADMIN', 'MAIN_ADMIN')
  @ApiOperation({ summary: 'Delete letter' })
  async remove(@Param('id', ParseUUIDPipe) id: string) {
    return this.service.remove(id);
  }
}
