// src/modules/letters/letters.service.ts
import { Injectable, NotFoundException, BadRequestException } from '@nestjs/common';
import { PrismaService } from '../../prisma/prisma.service';
import { CloudinaryService } from '../../config/cloudinary.service';

@Injectable()
export class LettersService {
  constructor(
    private readonly prisma: PrismaService,
    private readonly cloudinary: CloudinaryService,
  ) {}

  async findAll() {
    return this.prisma.letter.findMany({
      where: { deletedAt: null },
      orderBy: { createdAt: 'desc' },
    });
  }

  async create(
    body: { title: string; content: string; recipient?: string },
    files: Express.Multer.File[],
    createdBy: string,
  ) {
    if (!body.title?.trim() || !body.content?.trim()) {
      throw new BadRequestException('Title and content are required');
    }
    const mediaFiles: string[] = [];
    for (const file of files) {
      const url = await this.cloudinary.upload(file, 'letters');
      mediaFiles.push(url);
    }
    return this.prisma.letter.create({
      data: {
        title: body.title.trim(),
        content: body.content.trim(),
        recipient: body.recipient?.trim(),
        createdBy,
        mediaFiles,
      },
    });
  }

  async remove(id: string) {
    const letter = await this.prisma.letter.findFirst({ where: { id, deletedAt: null } });
    if (!letter) throw new NotFoundException('Letter not found');
    await this.prisma.letter.update({ where: { id }, data: { deletedAt: new Date() } });
    return { message: 'Letter deleted' };
  }
}
