// src/modules/letters/letters.module.ts
import { Module } from '@nestjs/common';
import { LettersController } from './letters.controller';
import { LettersService } from './letters.service';
import { CloudinaryService } from '../../config/cloudinary.service';

@Module({
  controllers: [LettersController],
  providers: [LettersService, CloudinaryService],
})
export class LettersModule {}
