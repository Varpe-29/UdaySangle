// src/modules/appointments/appointments.controller.ts
import {
  Controller, Get, Post, Patch, Delete, Body, Param, Query,
  UseGuards, UseInterceptors, UploadedFiles, ParseUUIDPipe, HttpCode, HttpStatus,
} from '@nestjs/common';
import { FilesInterceptor } from '@nestjs/platform-express';
import { ApiTags, ApiOperation, ApiBearerAuth } from '@nestjs/swagger';
import { JwtAuthGuard } from '../../common/guards/jwt-auth.guard';
import { RolesGuard } from '../../common/guards/roles.guard';
import { Roles } from '../../common/decorators/roles.decorator';
import { Public } from '../../common/decorators/public.decorator';
import { CurrentUser } from '../../common/decorators/current-user.decorator';
import { AppointmentsService } from './appointments.service';
import { multerConfig } from '../../config/multer.config';

@ApiTags('Appointments')
@Controller({ path: 'appointments', version: '1' })
@UseGuards(JwtAuthGuard, RolesGuard)
export class AppointmentsController {
  constructor(private readonly service: AppointmentsService) {}

  @Post()
  @Public()
  @HttpCode(HttpStatus.CREATED)
  @UseInterceptors(FilesInterceptor('files', 5, multerConfig))
  @ApiOperation({ summary: 'Book appointment (public)' })
  async create(@Body() body: any, @UploadedFiles() files: Express.Multer.File[]) {
    return this.service.create(body, files || []);
  }

  @Get()
  @Roles('SUPER_ADMIN', 'MAIN_ADMIN', 'STAFF_ADMIN')
  @ApiBearerAuth('access-token')
  @ApiOperation({ summary: 'Get all appointments (admin)' })
  async findAll(@Query() query: any) {
    return this.service.findAll(query);
  }

  @Get(':id')
  @Roles('SUPER_ADMIN', 'MAIN_ADMIN', 'STAFF_ADMIN')
  @ApiBearerAuth('access-token')
  async findOne(@Param('id', ParseUUIDPipe) id: string) {
    return this.service.findOne(id);
  }

  @Patch(':id/status')
  @Roles('SUPER_ADMIN', 'MAIN_ADMIN')
  @ApiBearerAuth('access-token')
  @ApiOperation({ summary: 'Update appointment status' })
  async updateStatus(
    @Param('id', ParseUUIDPipe) id: string,
    @Body() body: { status: string; notes?: string },
    @CurrentUser() user: any,
  ) {
    return this.service.updateStatus(id, body, user.sub);
  }

  @Delete(':id')
  @Roles('SUPER_ADMIN', 'MAIN_ADMIN')
  @ApiBearerAuth('access-token')
  async remove(@Param('id', ParseUUIDPipe) id: string) {
    return this.service.remove(id);
  }

  @Get('stats/summary')
  @Roles('SUPER_ADMIN', 'MAIN_ADMIN', 'STAFF_ADMIN')
  @ApiBearerAuth('access-token')
  async getStats() {
    return this.service.getStats();
  }
}
