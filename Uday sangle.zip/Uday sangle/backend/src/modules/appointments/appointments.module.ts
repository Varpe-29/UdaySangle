// src/modules/appointments/appointments.module.ts
import { Module } from '@nestjs/common';
import { AppointmentsController } from './appointments.controller';
import { AppointmentsService } from './appointments.service';
import { CloudinaryService } from '../../config/cloudinary.service';

@Module({
  controllers: [AppointmentsController],
  providers: [AppointmentsService, CloudinaryService],
  exports: [AppointmentsService],
})
export class AppointmentsModule {}
