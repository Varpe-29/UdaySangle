// src/modules/appointments/appointments.service.ts
import { Injectable, NotFoundException, BadRequestException } from '@nestjs/common';
import { PrismaService } from '../../prisma/prisma.service';
import { CloudinaryService } from '../../config/cloudinary.service';
import { AppointmentStatus } from '@prisma/client';

@Injectable()
export class AppointmentsService {
  constructor(
    private readonly prisma: PrismaService,
    private readonly cloudinary: CloudinaryService,
  ) {}

  async create(body: any, files: Express.Multer.File[]) {
    const { full_name, mobile, area, purpose, date, time } = body;
    if (!full_name || !mobile || !area || !purpose || !date || !time) {
      throw new BadRequestException('All fields are required');
    }
    if (!/^\d{10}$/.test(mobile)) {
      throw new BadRequestException('Mobile must be 10 digits');
    }
    const mediaFiles: string[] = [];
    for (const file of files) {
      const url = await this.cloudinary.upload(file, 'appointments');
      mediaFiles.push(url);
    }
    const appt = await this.prisma.appointment.create({
      data: {
        fullName: full_name, mobile, area, purpose,
        appointmentDate: new Date(date), appointmentTime: time, mediaFiles,
      },
    });
    return { id: appt.id, message: 'Appointment booked successfully' };
  }

  async findAll(query: any) {
    const { page = 1, limit = 10, search, status, sortBy = 'appointmentDate', sortOrder = 'asc' } = query;
    const skip = (Number(page) - 1) * Number(limit);
    const where: any = { deletedAt: null };
    if (status) where.status = status;
    if (search) {
      where.OR = [
        { fullName: { contains: search, mode: 'insensitive' } },
        { area: { contains: search, mode: 'insensitive' } },
        { mobile: { contains: search } },
      ];
    }
    const [total, data] = await Promise.all([
      this.prisma.appointment.count({ where }),
      this.prisma.appointment.findMany({
        where, skip, take: Number(limit), orderBy: { [sortBy]: sortOrder },
      }),
    ]);
    return { data, meta: { total, page: Number(page), limit: Number(limit), totalPages: Math.ceil(total / Number(limit)) } };
  }

  async findOne(id: string) {
    const appt = await this.prisma.appointment.findFirst({ where: { id, deletedAt: null } });
    if (!appt) throw new NotFoundException('Appointment not found');
    return appt;
  }

  async updateStatus(id: string, body: { status: string; notes?: string }, _userId: string) {
    await this.findOne(id);
    return this.prisma.appointment.update({
      where: { id },
      data: { status: body.status as AppointmentStatus, ...(body.notes && { notes: body.notes }) },
    });
  }

  async remove(id: string) {
    await this.findOne(id);
    await this.prisma.appointment.update({ where: { id }, data: { deletedAt: new Date() } });
    return { message: 'Appointment deleted' };
  }

  async getStats() {
    const [total, pending, confirmed, cancelled, completed] = await Promise.all([
      this.prisma.appointment.count({ where: { deletedAt: null } }),
      this.prisma.appointment.count({ where: { status: 'PENDING', deletedAt: null } }),
      this.prisma.appointment.count({ where: { status: 'CONFIRMED', deletedAt: null } }),
      this.prisma.appointment.count({ where: { status: 'CANCELLED', deletedAt: null } }),
      this.prisma.appointment.count({ where: { status: 'COMPLETED', deletedAt: null } }),
    ]);
    return { total, pending, confirmed, cancelled, completed };
  }
}
