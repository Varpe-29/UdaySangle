// src/modules/auth/auth.service.spec.ts
import { Test, TestingModule } from '@nestjs/testing';
import { JwtService } from '@nestjs/jwt';
import { ConfigService } from '@nestjs/config';
import { UnauthorizedException, ForbiddenException } from '@nestjs/common';
import { AuthService } from './auth.service';
import { PrismaService } from '../../prisma/prisma.service';
import * as bcrypt from 'bcrypt';

// ── Mock Prisma ───────────────────────────────────────────────
const mockPrisma = {
  user: {
    findFirst: jest.fn(),
    update: jest.fn(),
  },
  refreshToken: {
    create: jest.fn(),
    findUnique: jest.fn(),
    update: jest.fn(),
    updateMany: jest.fn(),
  },
  session: {
    create: jest.fn(),
    updateMany: jest.fn(),
  },
  activityLog: {
    create: jest.fn(),
  },
};

const mockJwtService = {
  sign: jest.fn(() => 'mock.jwt.token'),
};

const mockConfigService = {
  get: jest.fn((key: string, def?: any) => def ?? 'mock-value'),
};

describe('AuthService', () => {
  let service: AuthService;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      providers: [
        AuthService,
        { provide: PrismaService, useValue: mockPrisma },
        { provide: JwtService, useValue: mockJwtService },
        { provide: ConfigService, useValue: mockConfigService },
      ],
    }).compile();

    service = module.get<AuthService>(AuthService);
    jest.clearAllMocks();
  });

  describe('validateUser', () => {
    it('should throw UnauthorizedException for unknown username', async () => {
      mockPrisma.user.findFirst.mockResolvedValue(null);
      await expect(service.validateUser('nobody', 'pass')).rejects.toThrow(
        UnauthorizedException,
      );
    });

    it('should throw ForbiddenException for inactive user', async () => {
      mockPrisma.user.findFirst.mockResolvedValue({
        id: '1', username: 'test', isActive: false, isLocked: false,
        passwordHash: 'hash', failedAttempts: 0,
      });
      await expect(service.validateUser('test', 'pass')).rejects.toThrow(
        ForbiddenException,
      );
    });

    it('should throw ForbiddenException for locked user within lock window', async () => {
      const lockedUntil = new Date(Date.now() + 60_000); // locked for 1 more minute
      mockPrisma.user.findFirst.mockResolvedValue({
        id: '1', username: 'test', isActive: true, isLocked: true,
        lockedUntil, passwordHash: 'hash', failedAttempts: 5,
      });
      await expect(service.validateUser('test', 'pass')).rejects.toThrow(
        ForbiddenException,
      );
    });

    it('should return user for correct credentials', async () => {
      const hash = await bcrypt.hash('correctpass', 12);
      const mockUser = {
        id: 'uuid-1', username: 'admin', isActive: true, isLocked: false,
        passwordHash: hash, failedAttempts: 0, lockedUntil: null,
      };
      mockPrisma.user.findFirst.mockResolvedValue(mockUser);
      mockPrisma.user.update.mockResolvedValue(mockUser);

      const result = await service.validateUser('admin', 'correctpass');
      expect(result.username).toBe('admin');
    });

    it('should increment failedAttempts for wrong password', async () => {
      const hash = await bcrypt.hash('correct', 12);
      mockPrisma.user.findFirst.mockResolvedValue({
        id: '1', username: 'admin', isActive: true, isLocked: false,
        passwordHash: hash, failedAttempts: 0, lockedUntil: null,
      });
      mockPrisma.user.update.mockResolvedValue({});

      await expect(service.validateUser('admin', 'wrong')).rejects.toThrow(
        UnauthorizedException,
      );
      expect(mockPrisma.user.update).toHaveBeenCalledWith(
        expect.objectContaining({
          data: expect.objectContaining({ failedAttempts: 1 }),
        }),
      );
    });

    it('should lock account after 5 failed attempts', async () => {
      const hash = await bcrypt.hash('correct', 12);
      mockPrisma.user.findFirst.mockResolvedValue({
        id: '1', username: 'admin', isActive: true, isLocked: false,
        passwordHash: hash, failedAttempts: 4, lockedUntil: null,
      });
      mockPrisma.user.update.mockResolvedValue({});

      await expect(service.validateUser('admin', 'wrong')).rejects.toThrow(
        UnauthorizedException,
      );
      expect(mockPrisma.user.update).toHaveBeenCalledWith(
        expect.objectContaining({
          data: expect.objectContaining({ isLocked: true }),
        }),
      );
    });
  });

  describe('hashPassword', () => {
    it('should return a bcrypt hash', async () => {
      const hash = await service.hashPassword('MyPass123!');
      expect(hash).toBeTruthy();
      expect(hash).not.toBe('MyPass123!');
      const valid = await bcrypt.compare('MyPass123!', hash);
      expect(valid).toBe(true);
    });
  });

  describe('logoutAll', () => {
    it('should revoke all refresh tokens and sessions', async () => {
      mockPrisma.refreshToken.updateMany.mockResolvedValue({ count: 2 });
      mockPrisma.session.updateMany.mockResolvedValue({ count: 1 });

      await service.logoutAll('user-id-1');

      expect(mockPrisma.refreshToken.updateMany).toHaveBeenCalledWith(
        expect.objectContaining({ data: { isRevoked: true } }),
      );
      expect(mockPrisma.session.updateMany).toHaveBeenCalledWith(
        expect.objectContaining({ data: { isActive: false } }),
      );
    });
  });
});
