// src/modules/complaints/complaints.service.ts
import { Injectable, NotFoundException, BadRequestException, Logger } from '@nestjs/common';
import { PrismaService } from '../../prisma/prisma.service';
import { CreateComplaintDto } from './dto/create-complaint.dto';
import { UpdateComplaintStatusDto } from './dto/update-complaint-status.dto';
import { AddComplaintEntryDto } from './dto/add-complaint-entry.dto';
import { ComplaintQueryDto } from './dto/complaint-query.dto';
import { CloudinaryService } from '../../config/cloudinary.service';
import { ComplaintStatus } from '@prisma/client';

@Injectable()
export class ComplaintsService {
  private readonly logger = new Logger(ComplaintsService.name);

  constructor(
    private readonly prisma: PrismaService,
    private readonly cloudinary: CloudinaryService,
  ) {}

  async create(dto: CreateComplaintDto, files: Express.Multer.File[]) {
    // Validate mobile
    if (!/^\d{10}$/.test(dto.mobile)) {
      throw new BadRequestException('Mobile must be exactly 10 digits');
    }

    // Upload files to Cloudinary
    const mediaFiles: string[] = [];
    for (const file of files) {
      const url = await this.cloudinary.upload(file, 'complaints');
      mediaFiles.push(url);
    }

    const complaint = await this.prisma.complaint.create({
      data: {
        fullName: dto.full_name,
        mobile: dto.mobile,
        area: dto.area,
        subject: dto.subject,
        details: dto.details,
        complaintDate: new Date(dto.date),
        mediaFiles,
      },
    });

    this.logger.log(`New complaint submitted: ${complaint.id}`);
    return { id: complaint.id, message: 'Complaint submitted successfully' };
  }

  async getPublicComplaints() {
    return this.prisma.complaint.findMany({
      where: {
        status: { in: [ComplaintStatus.APPROVED, ComplaintStatus.DONE] },
        deletedAt: null,
      },
      select: {
        id: true,
        fullName: true,
        area: true,
        subject: true,
        status: true,
        complaintDate: true,
        createdAt: true,
      },
      orderBy: { createdAt: 'desc' },
      take: 20,
    });
  }

  async findAll(query: ComplaintQueryDto) {
    const {
      page = 1,
      limit = 10,
      search,
      status,
      sortBy = 'createdAt',
      sortOrder = 'desc',
    } = query;

    const skip = (page - 1) * limit;

    const where: any = { deletedAt: null };
    if (status) where.status = status;
    if (search) {
      where.OR = [
        { fullName: { contains: search, mode: 'insensitive' } },
        { area: { contains: search, mode: 'insensitive' } },
        { subject: { contains: search, mode: 'insensitive' } },
        { mobile: { contains: search } },
      ];
    }

    const [total, complaints] = await Promise.all([
      this.prisma.complaint.count({ where }),
      this.prisma.complaint.findMany({
        where,
        skip,
        take: Number(limit),
        orderBy: { [sortBy]: sortOrder },
        include: { entries: { orderBy: { createdAt: 'desc' } } },
      }),
    ]);

    return {
      data: complaints,
      meta: {
        total,
        page: Number(page),
        limit: Number(limit),
        totalPages: Math.ceil(total / limit),
      },
    };
  }

  async findOne(id: string) {
    const complaint = await this.prisma.complaint.findFirst({
      where: { id, deletedAt: null },
      include: { entries: { orderBy: { createdAt: 'asc' } } },
    });
    if (!complaint) throw new NotFoundException('Complaint not found');
    return complaint;
  }

  async updateStatus(id: string, dto: UpdateComplaintStatusDto, updatedBy: string) {
    const complaint = await this.findOne(id);

    const updated = await this.prisma.complaint.update({
      where: { id },
      data: {
        status: dto.status as ComplaintStatus,
        ...(dto.status === 'DONE' && { resolvedAt: new Date() }),
      },
    });

    this.logger.log(`Complaint ${id} status updated to ${dto.status} by ${updatedBy}`);
    return updated;
  }

  async addEntry(id: string, dto: AddComplaintEntryDto, addedBy: string) {
    await this.findOne(id);
    return this.prisma.complaintEntry.create({
      data: { complaintId: id, note: dto.note, addedBy },
    });
  }

  async remove(id: string) {
    await this.findOne(id);
    await this.prisma.complaint.update({
      where: { id },
      data: { deletedAt: new Date() },
    });
    return { message: 'Complaint deleted successfully' };
  }

  // Analytics helper
  async getStats() {
    const [total, pending, approved, done, rejected, inProgress] = await Promise.all([
      this.prisma.complaint.count({ where: { deletedAt: null } }),
      this.prisma.complaint.count({ where: { status: 'PENDING', deletedAt: null } }),
      this.prisma.complaint.count({ where: { status: 'APPROVED', deletedAt: null } }),
      this.prisma.complaint.count({ where: { status: 'DONE', deletedAt: null } }),
      this.prisma.complaint.count({ where: { status: 'REJECTED', deletedAt: null } }),
      this.prisma.complaint.count({ where: { status: 'IN_PROGRESS', deletedAt: null } }),
    ]);
    return { total, pending, approved, done, rejected, inProgress };
  }
}
