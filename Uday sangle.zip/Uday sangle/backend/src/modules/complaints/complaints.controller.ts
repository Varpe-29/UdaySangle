// src/modules/complaints/complaints.controller.ts
import {
  Controller, Get, Post, Patch, Delete, Body, Param, Query,
  UseGuards, UseInterceptors, UploadedFiles, ParseUUIDPipe, HttpCode, HttpStatus,
} from '@nestjs/common';
import { FilesInterceptor } from '@nestjs/platform-express';
import { ApiTags, ApiOperation, ApiBearerAuth, ApiConsumes } from '@nestjs/swagger';
import { JwtAuthGuard } from '../../common/guards/jwt-auth.guard';
import { RolesGuard } from '../../common/guards/roles.guard';
import { Roles } from '../../common/decorators/roles.decorator';
import { Public } from '../../common/decorators/public.decorator';
import { CurrentUser } from '../../common/decorators/current-user.decorator';
import { ComplaintsService } from './complaints.service';
import { CreateComplaintDto } from './dto/create-complaint.dto';
import { UpdateComplaintStatusDto } from './dto/update-complaint-status.dto';
import { AddComplaintEntryDto } from './dto/add-complaint-entry.dto';
import { ComplaintQueryDto } from './dto/complaint-query.dto';
import { multerConfig } from '../../config/multer.config';

@ApiTags('Complaints')
@Controller({ path: 'complaints', version: '1' })
@UseGuards(JwtAuthGuard, RolesGuard)
export class ComplaintsController {
  constructor(private readonly complaintsService: ComplaintsService) {}

  // PUBLIC — citizens submit complaints without login
  @Post()
  @Public()
  @HttpCode(HttpStatus.CREATED)
  @UseInterceptors(FilesInterceptor('files', 5, multerConfig))
  @ApiConsumes('multipart/form-data')
  @ApiOperation({ summary: 'Submit a complaint (public)' })
  async create(
    @Body() dto: CreateComplaintDto,
    @UploadedFiles() files: Express.Multer.File[],
  ) {
    return this.complaintsService.create(dto, files || []);
  }

  // PUBLIC — homepage shows approved/done complaints
  @Get('public')
  @Public()
  @ApiOperation({ summary: 'Get public (approved) complaints for homepage' })
  async getPublic() {
    return this.complaintsService.getPublicComplaints();
  }

  // PROTECTED — admin views all complaints
  @Get()
  @Roles('SUPER_ADMIN', 'MAIN_ADMIN', 'STAFF_ADMIN')
  @ApiBearerAuth('access-token')
  @ApiOperation({ summary: 'Get all complaints (admin)' })
  async findAll(@Query() query: ComplaintQueryDto) {
    return this.complaintsService.findAll(query);
  }

  // PROTECTED — get single complaint
  @Get(':id')
  @Roles('SUPER_ADMIN', 'MAIN_ADMIN', 'STAFF_ADMIN')
  @ApiBearerAuth('access-token')
  @ApiOperation({ summary: 'Get complaint by ID' })
  async findOne(@Param('id', ParseUUIDPipe) id: string) {
    return this.complaintsService.findOne(id);
  }

  // MAIN_ADMIN only — update complaint status
  @Patch(':id/status')
  @Roles('SUPER_ADMIN', 'MAIN_ADMIN')
  @ApiBearerAuth('access-token')
  @ApiOperation({ summary: 'Update complaint status (admin only)' })
  async updateStatus(
    @Param('id', ParseUUIDPipe) id: string,
    @Body() dto: UpdateComplaintStatusDto,
    @CurrentUser() user: any,
  ) {
    return this.complaintsService.updateStatus(id, dto, user.sub);
  }

  // STAFF — add entry notes to a complaint
  @Post(':id/entries')
  @Roles('SUPER_ADMIN', 'MAIN_ADMIN', 'STAFF_ADMIN')
  @ApiBearerAuth('access-token')
  @ApiOperation({ summary: 'Add note/entry to complaint' })
  async addEntry(
    @Param('id', ParseUUIDPipe) id: string,
    @Body() dto: AddComplaintEntryDto,
    @CurrentUser() user: any,
  ) {
    return this.complaintsService.addEntry(id, dto, user.username);
  }

  // MAIN_ADMIN only — soft delete
  @Delete(':id')
  @Roles('SUPER_ADMIN', 'MAIN_ADMIN')
  @ApiBearerAuth('access-token')
  @ApiOperation({ summary: 'Delete complaint (soft delete)' })
  async remove(@Param('id', ParseUUIDPipe) id: string) {
    return this.complaintsService.remove(id);
  }
}
