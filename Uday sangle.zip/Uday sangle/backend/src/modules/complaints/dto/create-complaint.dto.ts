// src/modules/complaints/dto/create-complaint.dto.ts
import { IsString, IsNotEmpty, IsDateString, Matches, MaxLength } from 'class-validator';
import { ApiProperty } from '@nestjs/swagger';
import { Transform } from 'class-transformer';

export class CreateComplaintDto {
  @ApiProperty({ example: 'Rahul Patil' })
  @IsString() @IsNotEmpty() @MaxLength(100)
  @Transform(({ value }) => value?.trim())
  full_name: string;

  @ApiProperty({ example: '9876543210' })
  @IsString() @IsNotEmpty()
  @Matches(/^\d{10}$/, { message: 'Mobile must be 10 digits' })
  mobile: string;

  @ApiProperty({ example: 'Pune, Maharashtra' })
  @IsString() @IsNotEmpty() @MaxLength(200)
  @Transform(({ value }) => value?.trim())
  area: string;

  @ApiProperty({ example: 'Road Repair Required' })
  @IsString() @IsNotEmpty() @MaxLength(200)
  @Transform(({ value }) => value?.trim())
  subject: string;

  @ApiProperty({ example: 'The main road near school is broken...' })
  @IsString() @IsNotEmpty() @MaxLength(2000)
  @Transform(({ value }) => value?.trim())
  details: string;

  @ApiProperty({ example: '2024-01-15' })
  @IsDateString()
  date: string;
}

// src/modules/complaints/dto/update-complaint-status.dto.ts
import { IsEnum } from 'class-validator';
import { ApiProperty } from '@nestjs/swagger';

export class UpdateComplaintStatusDto {
  @ApiProperty({ enum: ['PENDING', 'IN_PROGRESS', 'APPROVED', 'DONE', 'REJECTED'] })
  @IsEnum(['PENDING', 'IN_PROGRESS', 'APPROVED', 'DONE', 'REJECTED'])
  status: string;
}

// src/modules/complaints/dto/add-complaint-entry.dto.ts
import { IsString, IsNotEmpty, MaxLength } from 'class-validator';
import { ApiProperty } from '@nestjs/swagger';

export class AddComplaintEntryDto {
  @ApiProperty({ example: 'Forwarded to PWD department' })
  @IsString() @IsNotEmpty() @MaxLength(1000)
  @Transform(({ value }) => value?.trim())
  note: string;
}

// src/modules/complaints/dto/complaint-query.dto.ts
import { IsOptional, IsString, IsInt, Min, Max, IsEnum } from 'class-validator';
import { Transform, Type } from 'class-transformer';
import { ApiPropertyOptional } from '@nestjs/swagger';

export class ComplaintQueryDto {
  @ApiPropertyOptional({ default: 1 })
  @IsOptional() @Type(() => Number) @IsInt() @Min(1)
  page?: number = 1;

  @ApiPropertyOptional({ default: 10 })
  @IsOptional() @Type(() => Number) @IsInt() @Min(1) @Max(100)
  limit?: number = 10;

  @ApiPropertyOptional()
  @IsOptional() @IsString()
  search?: string;

  @ApiPropertyOptional({ enum: ['PENDING', 'IN_PROGRESS', 'APPROVED', 'DONE', 'REJECTED'] })
  @IsOptional() @IsEnum(['PENDING', 'IN_PROGRESS', 'APPROVED', 'DONE', 'REJECTED'])
  status?: string;

  @ApiPropertyOptional({ default: 'createdAt' })
  @IsOptional() @IsString()
  sortBy?: string = 'createdAt';

  @ApiPropertyOptional({ enum: ['asc', 'desc'], default: 'desc' })
  @IsOptional() @IsEnum(['asc', 'desc'])
  sortOrder?: 'asc' | 'desc' = 'desc';
}
