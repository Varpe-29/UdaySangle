// src/modules/complaints/complaints.service.spec.ts
import { Test, TestingModule } from '@nestjs/testing';
import { NotFoundException, BadRequestException } from '@nestjs/common';
import { ComplaintsService } from './complaints.service';
import { PrismaService } from '../../prisma/prisma.service';
import { CloudinaryService } from '../../config/cloudinary.service';

const mockPrisma = {
  complaint: {
    create: jest.fn(),
    findMany: jest.fn(),
    findFirst: jest.fn(),
    update: jest.fn(),
    count: jest.fn(),
  },
  complaintEntry: { create: jest.fn() },
};

const mockCloudinary = {
  upload: jest.fn().mockResolvedValue('https://res.cloudinary.com/test/image.jpg'),
};

describe('ComplaintsService', () => {
  let service: ComplaintsService;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      providers: [
        ComplaintsService,
        { provide: PrismaService, useValue: mockPrisma },
        { provide: CloudinaryService, useValue: mockCloudinary },
      ],
    }).compile();

    service = module.get<ComplaintsService>(ComplaintsService);
    jest.clearAllMocks();
  });

  describe('create', () => {
    const validDto = {
      full_name: 'Rahul Patil',
      mobile: '9876543210',
      area: 'Pune',
      subject: 'Road repair',
      details: 'The road near school needs urgent repair.',
      date: '2024-01-15',
    };

    it('should create a complaint successfully', async () => {
      mockPrisma.complaint.create.mockResolvedValue({ id: 'uuid-1', ...validDto });
      const result = await service.create(validDto, []);
      expect(result.message).toBe('Complaint submitted successfully');
      expect(mockPrisma.complaint.create).toHaveBeenCalledTimes(1);
    });

    it('should reject invalid mobile number', async () => {
      await expect(
        service.create({ ...validDto, mobile: '12345' }, []),
      ).rejects.toThrow(BadRequestException);
    });

    it('should upload files to cloudinary', async () => {
      mockPrisma.complaint.create.mockResolvedValue({ id: 'uuid-2' });
      const mockFile = { buffer: Buffer.from('test'), mimetype: 'image/jpeg' } as any;
      await service.create(validDto, [mockFile]);
      expect(mockCloudinary.upload).toHaveBeenCalledWith(mockFile, 'complaints');
    });
  });

  describe('findOne', () => {
    it('should throw NotFoundException for missing complaint', async () => {
      mockPrisma.complaint.findFirst.mockResolvedValue(null);
      await expect(service.findOne('nonexistent-id')).rejects.toThrow(NotFoundException);
    });

    it('should return the complaint when found', async () => {
      const complaint = { id: 'uuid-1', fullName: 'Test', entries: [] };
      mockPrisma.complaint.findFirst.mockResolvedValue(complaint);
      const result = await service.findOne('uuid-1');
      expect(result.id).toBe('uuid-1');
    });
  });

  describe('findAll', () => {
    it('should return paginated results', async () => {
      mockPrisma.complaint.count.mockResolvedValue(25);
      mockPrisma.complaint.findMany.mockResolvedValue([{ id: '1' }, { id: '2' }]);

      const result = await service.findAll({ page: 2, limit: 10 });
      expect(result.meta.total).toBe(25);
      expect(result.meta.totalPages).toBe(3);
      expect(result.meta.page).toBe(2);
    });
  });

  describe('updateStatus', () => {
    it('should update complaint status', async () => {
      const complaint = { id: 'uuid-1', fullName: 'Test', entries: [], status: 'PENDING' };
      mockPrisma.complaint.findFirst.mockResolvedValue(complaint);
      mockPrisma.complaint.update.mockResolvedValue({ ...complaint, status: 'DONE' });

      const result = await service.updateStatus(
        'uuid-1',
        { status: 'DONE' },
        'admin',
      );
      expect(mockPrisma.complaint.update).toHaveBeenCalledWith(
        expect.objectContaining({ data: expect.objectContaining({ status: 'DONE' }) }),
      );
    });
  });
});
