// src/modules/complaints/complaints.module.ts
import { Module } from '@nestjs/common';
import { ComplaintsController } from './complaints.controller';
import { ComplaintsService } from './complaints.service';
import { CloudinaryService } from '../../config/cloudinary.service';

@Module({
  controllers: [ComplaintsController],
  providers: [ComplaintsService, CloudinaryService],
  exports: [ComplaintsService],
})
export class ComplaintsModule {}
