// src/modules/notices/notices.module.ts
import { Module } from '@nestjs/common';
import { NoticesController } from './notices.controller';
import { NoticesService } from './notices.service';
import { CloudinaryService } from '../../config/cloudinary.service';

@Module({
  controllers: [NoticesController],
  providers: [NoticesService, CloudinaryService],
})
export class NoticesModule {}
