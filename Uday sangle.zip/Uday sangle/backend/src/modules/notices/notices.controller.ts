// src/modules/notices/notices.controller.ts
import {
  Controller, Get, Post, Delete, Body, Param, UseGuards,
  UseInterceptors, UploadedFiles, ParseUUIDPipe, HttpCode, HttpStatus,
} from '@nestjs/common';
import { FilesInterceptor } from '@nestjs/platform-express';
import { ApiTags, ApiOperation, ApiBearerAuth } from '@nestjs/swagger';
import { JwtAuthGuard } from '../../common/guards/jwt-auth.guard';
import { RolesGuard } from '../../common/guards/roles.guard';
import { Roles } from '../../common/decorators/roles.decorator';
import { Public } from '../../common/decorators/public.decorator';
import { CurrentUser } from '../../common/decorators/current-user.decorator';
import { NoticesService } from './notices.service';
import { multerConfig } from '../../config/multer.config';

@ApiTags('Notices')
@Controller({ path: 'notices', version: '1' })
@UseGuards(JwtAuthGuard, RolesGuard)
export class NoticesController {
  constructor(private readonly service: NoticesService) {}

  @Get()
  @Public()
  @ApiOperation({ summary: 'Get all public notices' })
  async findAll() {
    return this.service.findAll();
  }

  @Post()
  @Roles('SUPER_ADMIN', 'MAIN_ADMIN', 'STAFF_ADMIN')
  @HttpCode(HttpStatus.CREATED)
  @UseInterceptors(FilesInterceptor('files', 5, multerConfig))
  @ApiBearerAuth('access-token')
  @ApiOperation({ summary: 'Post a notice' })
  async create(
    @Body() body: { title: string; content?: string; isPublic?: string },
    @UploadedFiles() files: Express.Multer.File[],
    @CurrentUser() user: any,
  ) {
    return this.service.create(body, files || [], user.username);
  }

  @Delete(':id')
  @Roles('SUPER_ADMIN', 'MAIN_ADMIN')
  @ApiBearerAuth('access-token')
  @ApiOperation({ summary: 'Delete notice' })
  async remove(@Param('id', ParseUUIDPipe) id: string) {
    return this.service.remove(id);
  }
}
