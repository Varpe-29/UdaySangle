// src/modules/notices/notices.service.ts
import { Injectable, NotFoundException, BadRequestException } from '@nestjs/common';
import { PrismaService } from '../../prisma/prisma.service';
import { CloudinaryService } from '../../config/cloudinary.service';

@Injectable()
export class NoticesService {
  constructor(
    private readonly prisma: PrismaService,
    private readonly cloudinary: CloudinaryService,
  ) {}

  async findAll() {
    return this.prisma.notice.findMany({
      where: { deletedAt: null },
      orderBy: { createdAt: 'desc' },
    });
  }

  async create(
    body: { title: string; content?: string; isPublic?: string },
    files: Express.Multer.File[],
    postedBy: string,
  ) {
    if (!body.title?.trim()) throw new BadRequestException('Title is required');

    const mediaFiles: string[] = [];
    for (const file of files) {
      const url = await this.cloudinary.upload(file, 'notices');
      mediaFiles.push(url);
    }

    return this.prisma.notice.create({
      data: {
        title: body.title.trim(),
        content: body.content?.trim() || '',
        mediaFiles,
        isPublic: body.isPublic !== 'false',
        postedBy,
      },
    });
  }

  async remove(id: string) {
    const notice = await this.prisma.notice.findFirst({ where: { id, deletedAt: null } });
    if (!notice) throw new NotFoundException('Notice not found');
    await this.prisma.notice.update({ where: { id }, data: { deletedAt: new Date() } });
    return { message: 'Notice deleted' };
  }
}
