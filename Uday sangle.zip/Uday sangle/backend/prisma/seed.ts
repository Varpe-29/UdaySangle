// prisma/seed.ts
import { PrismaClient, Role } from '@prisma/client';
import * as bcrypt from 'bcrypt';

const prisma = new PrismaClient();

async function main() {
  console.log('🌱 Seeding database...');

  // ── Create Super Admin ────────────────────────────────────
  const superAdminPassword = process.env.SUPER_ADMIN_PASSWORD || 'SuperAdmin@2024!';
  const superAdminHash = await bcrypt.hash(superAdminPassword, 12);

  const superAdmin = await prisma.user.upsert({
    where: { username: 'superadmin' },
    update: {},
    create: {
      username: 'superadmin',
      email: 'superadmin@office.local',
      passwordHash: superAdminHash,
      role: Role.SUPER_ADMIN,
      isActive: true,
    },
  });
  console.log(`✅ Super Admin created: ${superAdmin.username}`);

  // ── Create Main Admin ─────────────────────────────────────
  const mainAdminPassword = process.env.MAIN_ADMIN_PASSWORD || 'MainAdmin@2024!';
  const mainAdminHash = await bcrypt.hash(mainAdminPassword, 12);

  const mainAdmin = await prisma.user.upsert({
    where: { username: 'admin' },
    update: {},
    create: {
      username: 'admin',
      email: 'admin@office.local',
      passwordHash: mainAdminHash,
      role: Role.MAIN_ADMIN,
      isActive: true,
    },
  });
  console.log(`✅ Main Admin created: ${mainAdmin.username}`);

  // ── Create Staff Admin ────────────────────────────────────
  const staffPassword = process.env.STAFF_PASSWORD || 'Staff@2024!';
  const staffHash = await bcrypt.hash(staffPassword, 12);

  const staff = await prisma.user.upsert({
    where: { username: 'staff' },
    update: {},
    create: {
      username: 'staff',
      email: 'staff@office.local',
      passwordHash: staffHash,
      role: Role.STAFF_ADMIN,
      isActive: true,
    },
  });
  console.log(`✅ Staff Admin created: ${staff.username}`);

  // ── Default Settings ──────────────────────────────────────
  const settings = [
    { key: 'office_name', value: 'Uday Sangle Office', category: 'general' },
    { key: 'office_state', value: 'Maharashtra', category: 'general' },
    { key: 'office_phone', value: '', category: 'contact' },
    { key: 'office_email', value: '', category: 'contact' },
    { key: 'office_address', value: '', category: 'contact' },
    { key: 'max_appointments_per_day', value: '20', category: 'scheduling' },
    { key: 'appointment_start_time', value: '10:00', category: 'scheduling' },
    { key: 'appointment_end_time', value: '17:00', category: 'scheduling' },
    { key: 'maintenance_mode', value: 'false', category: 'system' },
  ];

  for (const setting of settings) {
    await prisma.setting.upsert({
      where: { key: setting.key },
      update: {},
      create: setting,
    });
  }
  console.log('✅ Default settings seeded');

  // ── Welcome Notification ──────────────────────────────────
  await prisma.notification.create({
    data: {
      userId: superAdmin.id,
      title: 'Welcome to Office Management System',
      message: 'Your enterprise dashboard is ready. Start by reviewing pending complaints and appointments.',
      type: 'info',
    },
  });
  console.log('✅ Welcome notification created');

  console.log('\n🎉 Seed complete!');
  console.log('─────────────────────────────────────────');
  console.log('Default credentials (CHANGE IMMEDIATELY):');
  console.log(`  Super Admin → superadmin / ${superAdminPassword}`);
  console.log(`  Main Admin  → admin      / ${mainAdminPassword}`);
  console.log(`  Staff       → staff      / ${staffPassword}`);
  console.log('─────────────────────────────────────────');
}

main()
  .catch((e) => {
    console.error('❌ Seed failed:', e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
