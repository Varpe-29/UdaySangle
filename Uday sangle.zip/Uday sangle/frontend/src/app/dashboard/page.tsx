'use client';

import { useQuery } from '@tanstack/react-query';
import { motion } from 'framer-motion';
import {
  AreaChart, Area, BarChart, Bar, XAxis, YAxis, CartesianGrid,
  Tooltip, ResponsiveContainer, PieChart, Pie, Cell, Legend,
} from 'recharts';
import {
  FileText, Calendar, Bell, Mail, Users, TrendingUp,
  TrendingDown, Minus, AlertCircle, CheckCircle2, Clock,
} from 'lucide-react';
import { adminService } from '@/services/complaints.service';
import { useAuthStore } from '@/store/auth.store';
import { formatDistanceToNow } from 'date-fns';

const COLORS = ['#3b82f6', '#10b981', '#f59e0b', '#ef4444', '#8b5cf6'];

function StatCard({
  label, value, icon: Icon, color, growth, suffix = '',
}: {
  label: string; value: number | string; icon: any;
  color: string; growth?: number; suffix?: string;
}) {
  return (
    <motion.div
      whileHover={{ y: -2 }}
      className="bg-card border border-border rounded-xl p-5 flex items-start justify-between"
    >
      <div>
        <p className="text-muted-foreground text-sm mb-1">{label}</p>
        <p className="text-2xl font-bold text-foreground">
          {value}{suffix}
        </p>
        {growth !== undefined && (
          <div className={`flex items-center gap-1 mt-1 text-xs ${growth > 0 ? 'text-emerald-500' : growth < 0 ? 'text-red-500' : 'text-muted-foreground'}`}>
            {growth > 0 ? <TrendingUp className="w-3 h-3" /> : growth < 0 ? <TrendingDown className="w-3 h-3" /> : <Minus className="w-3 h-3" />}
            <span>{Math.abs(growth)}% vs last month</span>
          </div>
        )}
      </div>
      <div className={`w-10 h-10 rounded-xl flex items-center justify-center ${color}`}>
        <Icon className="w-5 h-5" />
      </div>
    </motion.div>
  );
}

export default function DashboardPage() {
  const { user } = useAuthStore();
  const { data, isLoading } = useQuery({
    queryKey: ['analytics'],
    queryFn: adminService.getAnalytics,
    refetchInterval: 5 * 60 * 1000, // refresh every 5 minutes
  });

  if (isLoading) {
    return (
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        {Array.from({ length: 8 }).map((_, i) => (
          <div key={i} className="bg-card border border-border rounded-xl p-5 h-28 animate-pulse" />
        ))}
      </div>
    );
  }

  const { overview, trends, monthlyChart, recentActivity } = data || {};

  const pieData = [
    { name: 'Pending', value: overview?.pendingComplaints || 0 },
    { name: 'Done', value: overview?.doneComplaints || 0 },
    { name: 'In Progress', value: (overview?.totalComplaints || 0) - (overview?.pendingComplaints || 0) - (overview?.doneComplaints || 0) },
  ].filter((d) => d.value > 0);

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h1 className="text-2xl font-bold text-foreground">Dashboard</h1>
        <p className="text-muted-foreground text-sm mt-0.5">
          Welcome back, <span className="text-foreground font-medium">{user?.username}</span>
        </p>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard
          label="Total Complaints" value={overview?.totalComplaints ?? 0}
          icon={FileText} color="bg-blue-500/10 text-blue-500"
          growth={trends?.complaintsGrowth}
        />
        <StatCard
          label="Pending Complaints" value={overview?.pendingComplaints ?? 0}
          icon={AlertCircle} color="bg-amber-500/10 text-amber-500"
        />
        <StatCard
          label="Resolved" value={overview?.doneComplaints ?? 0}
          icon={CheckCircle2} color="bg-emerald-500/10 text-emerald-500"
        />
        <StatCard
          label="Appointments" value={overview?.totalAppointments ?? 0}
          icon={Calendar} color="bg-purple-500/10 text-purple-500"
        />
        <StatCard
          label="Pending Appointments" value={overview?.pendingAppointments ?? 0}
          icon={Clock} color="bg-orange-500/10 text-orange-500"
        />
        <StatCard
          label="Active Notices" value={overview?.totalNotices ?? 0}
          icon={Bell} color="bg-cyan-500/10 text-cyan-500"
        />
        <StatCard
          label="Letters" value={overview?.totalLetters ?? 0}
          icon={Mail} color="bg-indigo-500/10 text-indigo-500"
        />
        <StatCard
          label="Admin Users" value={overview?.totalUsers ?? 0}
          icon={Users} color="bg-pink-500/10 text-pink-500"
        />
      </div>

      {/* Charts Row */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        {/* Area Chart - Monthly trend */}
        <div className="lg:col-span-2 bg-card border border-border rounded-xl p-5">
          <h2 className="font-semibold text-foreground mb-4 text-sm">Monthly Overview</h2>
          <ResponsiveContainer width="100%" height={220}>
            <AreaChart data={monthlyChart || []}>
              <defs>
                <linearGradient id="complaints" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#3b82f6" stopOpacity={0.15} />
                  <stop offset="95%" stopColor="#3b82f6" stopOpacity={0} />
                </linearGradient>
                <linearGradient id="appointments" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#10b981" stopOpacity={0.15} />
                  <stop offset="95%" stopColor="#10b981" stopOpacity={0} />
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
              <XAxis dataKey="month" tick={{ fontSize: 11, fill: 'hsl(var(--muted-foreground))' }} />
              <YAxis tick={{ fontSize: 11, fill: 'hsl(var(--muted-foreground))' }} />
              <Tooltip
                contentStyle={{
                  background: 'hsl(var(--card))',
                  border: '1px solid hsl(var(--border))',
                  borderRadius: '8px',
                  fontSize: '12px',
                }}
              />
              <Legend />
              <Area type="monotone" dataKey="complaints" stroke="#3b82f6" fill="url(#complaints)" strokeWidth={2} />
              <Area type="monotone" dataKey="appointments" stroke="#10b981" fill="url(#appointments)" strokeWidth={2} />
            </AreaChart>
          </ResponsiveContainer>
        </div>

        {/* Pie chart - complaint status */}
        <div className="bg-card border border-border rounded-xl p-5">
          <h2 className="font-semibold text-foreground mb-4 text-sm">Complaint Status</h2>
          {pieData.length > 0 ? (
            <ResponsiveContainer width="100%" height={220}>
              <PieChart>
                <Pie data={pieData} cx="50%" cy="50%" innerRadius={55} outerRadius={80} paddingAngle={3} dataKey="value">
                  {pieData.map((_, i) => (
                    <Cell key={i} fill={COLORS[i % COLORS.length]} />
                  ))}
                </Pie>
                <Tooltip contentStyle={{ background: 'hsl(var(--card))', border: '1px solid hsl(var(--border))', borderRadius: '8px', fontSize: '12px' }} />
                <Legend />
              </PieChart>
            </ResponsiveContainer>
          ) : (
            <div className="flex items-center justify-center h-52 text-muted-foreground text-sm">No data yet</div>
          )}
        </div>
      </div>

      {/* Recent Activity */}
      <div className="bg-card border border-border rounded-xl p-5">
        <h2 className="font-semibold text-foreground mb-4 text-sm">Recent Activity</h2>
        {recentActivity?.length ? (
          <div className="space-y-3">
            {recentActivity.slice(0, 8).map((log: any) => (
              <div key={log.id} className="flex items-center gap-3 text-sm">
                <div className="w-7 h-7 rounded-full bg-blue-500/10 border border-blue-500/20 flex items-center justify-center flex-shrink-0">
                  <span className="text-xs font-bold text-blue-400">
                    {log.user?.username?.[0]?.toUpperCase() || '?'}
                  </span>
                </div>
                <div className="flex-1 min-w-0">
                  <span className="font-medium text-foreground">{log.user?.username}</span>
                  <span className="text-muted-foreground"> performed </span>
                  <span className="text-foreground">{log.action}</span>
                  {log.entity && <span className="text-muted-foreground"> on {log.entity}</span>}
                </div>
                <span className="text-muted-foreground text-xs flex-shrink-0">
                  {formatDistanceToNow(new Date(log.createdAt), { addSuffix: true })}
                </span>
              </div>
            ))}
          </div>
        ) : (
          <p className="text-muted-foreground text-sm">No recent activity</p>
        )}
      </div>
    </div>
  );
}
