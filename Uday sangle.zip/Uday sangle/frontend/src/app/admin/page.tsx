'use client';

import { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { motion } from 'framer-motion';
import { Users, Activity, Plus, Lock, Unlock, Trash2, ChevronLeft, ChevronRight, Shield } from 'lucide-react';
import { adminService } from '@/services/complaints.service';
import { useAuthStore, isSuperAdmin, isMainAdmin } from '@/store/auth.store';
import toast from 'react-hot-toast';
import { formatDistanceToNow } from 'date-fns';
import clsx from 'clsx';

const ROLE_STYLES: Record<string, string> = {
  SUPER_ADMIN: 'bg-purple-500/10 text-purple-600 border-purple-500/20',
  MAIN_ADMIN: 'bg-blue-500/10 text-blue-600 border-blue-500/20',
  STAFF_ADMIN: 'bg-green-500/10 text-green-600 border-green-500/20',
};

const TABS = ['Users', 'Activity Logs'];

export default function AdminPage() {
  const { user } = useAuthStore();
  const qc = useQueryClient();
  const [tab, setTab] = useState('Users');
  const [page, setPage] = useState(1);
  const [showCreateForm, setShowCreateForm] = useState(false);
  const [newUser, setNewUser] = useState({ username: '', password: '', email: '', role: 'STAFF_ADMIN' });

  if (!isMainAdmin(user?.role)) {
    return (
      <div className="flex flex-col items-center justify-center py-24 text-muted-foreground">
        <Shield className="w-12 h-12 mb-3 opacity-30" />
        <p className="font-medium">Access Restricted</p>
        <p className="text-sm mt-1">You need Main Admin or Super Admin role.</p>
      </div>
    );
  }

  const { data: usersData, isLoading: usersLoading } = useQuery({
    queryKey: ['admin-users', page],
    queryFn: () => adminService.getUsers({ page, limit: 10 }),
    enabled: tab === 'Users',
  });

  const { data: logsData, isLoading: logsLoading } = useQuery({
    queryKey: ['activity-logs', page],
    queryFn: () => adminService.getActivityLogs({ page, limit: 15 }),
    enabled: tab === 'Activity Logs',
  });

  const createUser = useMutation({
    mutationFn: adminService.createUser,
    onSuccess: () => {
      toast.success('User created');
      setShowCreateForm(false);
      setNewUser({ username: '', password: '', email: '', role: 'STAFF_ADMIN' });
      qc.invalidateQueries({ queryKey: ['admin-users'] });
    },
    onError: (e: any) => toast.error(e?.response?.data?.message || 'Failed to create user'),
  });

  const toggleLock = useMutation({
    mutationFn: adminService.toggleUserLock,
    onSuccess: () => { toast.success('User lock status updated'); qc.invalidateQueries({ queryKey: ['admin-users'] }); },
  });

  const deleteUser = useMutation({
    mutationFn: adminService.deleteUser,
    onSuccess: () => { toast.success('User deleted'); qc.invalidateQueries({ queryKey: ['admin-users'] }); },
  });

  const users = usersData?.data || [];
  const usersMeta = usersData?.meta || { totalPages: 1 };
  const logs = logsData?.data || [];
  const logsMeta = logsData?.meta || { totalPages: 1 };

  return (
    <div className="space-y-5">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-xl font-bold text-foreground">Admin Panel</h1>
          <p className="text-muted-foreground text-sm">User management & system logs</p>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex gap-1 bg-muted rounded-lg p-1 w-fit">
        {TABS.map((t) => (
          <button
            key={t}
            onClick={() => { setTab(t); setPage(1); }}
            className={clsx(
              'px-4 py-1.5 text-sm font-medium rounded-md transition-all',
              tab === t ? 'bg-card text-foreground shadow-sm' : 'text-muted-foreground hover:text-foreground',
            )}
          >
            {t}
          </button>
        ))}
      </div>

      {/* Users Tab */}
      {tab === 'Users' && (
        <div className="space-y-4">
          {isSuperAdmin(user?.role) && (
            <div>
              <button
                onClick={() => setShowCreateForm(!showCreateForm)}
                className="flex items-center gap-2 px-4 py-2 text-sm bg-primary text-primary-foreground rounded-lg hover:bg-primary/90"
              >
                <Plus className="w-4 h-4" />
                Create User
              </button>
              {showCreateForm && (
                <motion.div initial={{ opacity: 0, y: -8 }} animate={{ opacity: 1, y: 0 }} className="mt-3 bg-card border border-border rounded-xl p-5">
                  <h3 className="font-semibold text-sm mb-4">New Admin User</h3>
                  <div className="grid grid-cols-2 gap-3">
                    {[
                      { key: 'username', label: 'Username *', type: 'text', required: true },
                      { key: 'email', label: 'Email', type: 'email' },
                      { key: 'password', label: 'Password *', type: 'password', required: true },
                    ].map(({ key, label, type, required }) => (
                      <div key={key}>
                        <label className="text-xs text-muted-foreground mb-1 block">{label}</label>
                        <input
                          type={type}
                          value={(newUser as any)[key]}
                          onChange={(e) => setNewUser((p) => ({ ...p, [key]: e.target.value }))}
                          required={required}
                          className="w-full px-3 py-2 text-sm rounded-lg border border-border bg-background focus:outline-none focus:ring-2 focus:ring-primary/30"
                        />
                      </div>
                    ))}
                    <div>
                      <label className="text-xs text-muted-foreground mb-1 block">Role</label>
                      <select
                        value={newUser.role}
                        onChange={(e) => setNewUser((p) => ({ ...p, role: e.target.value }))}
                        className="w-full px-3 py-2 text-sm rounded-lg border border-border bg-background focus:outline-none"
                      >
                        <option value="STAFF_ADMIN">Staff Admin</option>
                        <option value="MAIN_ADMIN">Main Admin</option>
                        <option value="SUPER_ADMIN">Super Admin</option>
                      </select>
                    </div>
                  </div>
                  <button
                    onClick={() => createUser.mutate(newUser)}
                    disabled={createUser.isPending || !newUser.username || !newUser.password}
                    className="mt-4 px-4 py-2 text-sm bg-primary text-primary-foreground rounded-lg hover:bg-primary/90 disabled:opacity-50"
                  >
                    {createUser.isPending ? 'Creating…' : 'Create User'}
                  </button>
                </motion.div>
              )}
            </div>
          )}

          <div className="bg-card border border-border rounded-xl overflow-hidden">
            {usersLoading ? (
              <div className="space-y-px">{Array.from({ length: 5 }).map((_, i) => <div key={i} className="h-14 bg-muted/30 animate-pulse" />)}</div>
            ) : (
              <table className="w-full">
                <thead>
                  <tr className="border-b border-border bg-muted/30">
                    {['User', 'Role', 'Status', 'Last Login', ''].map((h) => (
                      <th key={h} className="text-left text-xs font-medium text-muted-foreground px-4 py-2.5">{h}</th>
                    ))}
                  </tr>
                </thead>
                <tbody className="divide-y divide-border">
                  {users.map((u: any) => (
                    <tr key={u.id} className="hover:bg-muted/20">
                      <td className="px-4 py-3">
                        <div className="flex items-center gap-2">
                          <div className="w-7 h-7 rounded-full bg-primary/10 flex items-center justify-center text-xs font-bold text-primary">
                            {u.username[0].toUpperCase()}
                          </div>
                          <div>
                            <p className="text-sm font-medium text-foreground">{u.username}</p>
                            {u.email && <p className="text-xs text-muted-foreground">{u.email}</p>}
                          </div>
                        </div>
                      </td>
                      <td className="px-4 py-3">
                        <span className={clsx('inline-flex px-2 py-0.5 rounded-full text-xs font-medium border', ROLE_STYLES[u.role])}>
                          {u.role.replace(/_/g, ' ')}
                        </span>
                      </td>
                      <td className="px-4 py-3">
                        <span className={clsx('text-xs font-medium', u.isLocked ? 'text-red-500' : u.isActive ? 'text-emerald-500' : 'text-muted-foreground')}>
                          {u.isLocked ? '🔒 Locked' : u.isActive ? '✓ Active' : 'Inactive'}
                        </span>
                      </td>
                      <td className="px-4 py-3 text-xs text-muted-foreground">
                        {u.lastLoginAt ? formatDistanceToNow(new Date(u.lastLoginAt), { addSuffix: true }) : 'Never'}
                      </td>
                      <td className="px-4 py-3 pr-5">
                        {u.id !== user?.id && (
                          <div className="flex items-center gap-1">
                            <button
                              onClick={() => toggleLock.mutate(u.id)}
                              className="p-1.5 rounded-lg text-muted-foreground hover:bg-muted hover:text-foreground"
                              title={u.isLocked ? 'Unlock' : 'Lock'}
                            >
                              {u.isLocked ? <Unlock className="w-3.5 h-3.5" /> : <Lock className="w-3.5 h-3.5" />}
                            </button>
                            {isSuperAdmin(user?.role) && (
                              <button
                                onClick={() => { if (confirm('Delete this user?')) deleteUser.mutate(u.id); }}
                                className="p-1.5 rounded-lg text-muted-foreground hover:bg-red-500/10 hover:text-red-500"
                              >
                                <Trash2 className="w-3.5 h-3.5" />
                              </button>
                            )}
                          </div>
                        )}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            )}
          </div>

          {usersMeta.totalPages > 1 && (
            <div className="flex gap-1 justify-end">
              <button onClick={() => setPage((p) => Math.max(1, p - 1))} disabled={page === 1} className="p-1.5 rounded-lg border border-border hover:bg-muted disabled:opacity-40"><ChevronLeft className="w-4 h-4" /></button>
              <button onClick={() => setPage((p) => Math.min(usersMeta.totalPages, p + 1))} disabled={page === usersMeta.totalPages} className="p-1.5 rounded-lg border border-border hover:bg-muted disabled:opacity-40"><ChevronRight className="w-4 h-4" /></button>
            </div>
          )}
        </div>
      )}

      {/* Activity Logs Tab */}
      {tab === 'Activity Logs' && (
        <div className="bg-card border border-border rounded-xl overflow-hidden">
          {logsLoading ? (
            <div className="space-y-px">{Array.from({ length: 8 }).map((_, i) => <div key={i} className="h-12 bg-muted/30 animate-pulse" />)}</div>
          ) : logs.length === 0 ? (
            <div className="flex items-center justify-center py-12 text-muted-foreground text-sm"><Activity className="w-5 h-5 mr-2 opacity-50" />No activity yet</div>
          ) : (
            <div className="divide-y divide-border">
              {logs.map((log: any) => (
                <div key={log.id} className="flex items-center gap-3 px-5 py-3">
                  <div className="w-7 h-7 rounded-full bg-blue-500/10 border border-blue-500/20 flex items-center justify-center flex-shrink-0">
                    <span className="text-xs font-bold text-blue-400">{log.user?.username?.[0]?.toUpperCase()}</span>
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-sm text-foreground">
                      <span className="font-medium">{log.user?.username}</span>
                      <span className="text-muted-foreground"> · {log.action}</span>
                      {log.entity && <span className="text-muted-foreground"> on {log.entity}</span>}
                    </p>
                    {log.ipAddress && <p className="text-xs text-muted-foreground">IP: {log.ipAddress}</p>}
                  </div>
                  <span className="text-xs text-muted-foreground flex-shrink-0">
                    {formatDistanceToNow(new Date(log.createdAt), { addSuffix: true })}
                  </span>
                </div>
              ))}
            </div>
          )}
        </div>
      )}
    </div>
  );
}
