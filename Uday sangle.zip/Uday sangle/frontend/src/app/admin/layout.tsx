// Re-export the dashboard layout for all protected route groups
// Each protected route (complaints, appointments, etc.) uses this same layout

export { default } from '../dashboard/layout';
