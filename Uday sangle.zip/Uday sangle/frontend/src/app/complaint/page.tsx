'use client';

import { useState } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { motion } from 'framer-motion';
import { FileText, Upload, CheckCircle2, ArrowLeft, Paperclip, X } from 'lucide-react';
import Link from 'next/link';
import { complaintsService } from '@/services/complaints.service';
import { complaintSchema, ComplaintSchema } from '@/validations/auth.schema';
import toast from 'react-hot-toast';

export default function PublicComplaintPage() {
  const [files, setFiles] = useState<File[]>([]);
  const [submitted, setSubmitted] = useState(false);
  const [complaintId, setComplaintId] = useState('');

  const {
    register,
    handleSubmit,
    reset,
    formState: { errors, isSubmitting },
  } = useForm<ComplaintSchema>({ resolver: zodResolver(complaintSchema) });

  const onSubmit = async (data: ComplaintSchema) => {
    const fd = new FormData();
    Object.entries(data).forEach(([k, v]) => fd.append(k, v));
    files.forEach((f) => fd.append('files', f));

    try {
      const result = await complaintsService.submitPublic(fd);
      setComplaintId(result.id);
      setSubmitted(true);
      reset();
      setFiles([]);
    } catch (err: any) {
      toast.error(err?.response?.data?.message || 'Failed to submit. Please try again.');
    }
  };

  const removeFile = (i: number) => setFiles((prev) => prev.filter((_, idx) => idx !== i));

  if (submitted) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-50 to-blue-50 flex items-center justify-center p-4">
        <motion.div
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          className="bg-white rounded-2xl border border-slate-200 shadow-xl p-10 max-w-md w-full text-center"
        >
          <div className="w-16 h-16 rounded-full bg-emerald-100 flex items-center justify-center mx-auto mb-5">
            <CheckCircle2 className="w-8 h-8 text-emerald-600" />
          </div>
          <h2 className="text-xl font-bold text-slate-900 mb-2">Complaint Submitted!</h2>
          <p className="text-slate-600 text-sm mb-4">
            Your complaint has been received and will be reviewed by our team.
          </p>
          {complaintId && (
            <div className="bg-slate-50 rounded-lg p-3 mb-5">
              <p className="text-xs text-slate-500">Reference ID</p>
              <p className="font-mono text-sm font-semibold text-slate-800 break-all">{complaintId}</p>
            </div>
          )}
          <button
            onClick={() => setSubmitted(false)}
            className="w-full py-2.5 px-4 rounded-lg bg-blue-600 hover:bg-blue-500 text-white text-sm font-medium transition-colors"
          >
            Submit Another Complaint
          </button>
        </motion.div>
      </div>
    );
  }

  const Field = ({
    label, name, placeholder, type = 'text', required = false,
  }: { label: string; name: keyof ComplaintSchema; placeholder: string; type?: string; required?: boolean }) => (
    <div>
      <label className="block text-sm font-medium text-slate-700 mb-1.5">
        {label} {required && <span className="text-red-500">*</span>}
      </label>
      <input
        {...register(name)}
        type={type}
        placeholder={placeholder}
        className="w-full px-3.5 py-2.5 rounded-lg border border-slate-300 text-slate-900 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-blue-500/40 focus:border-blue-500 text-sm transition-all"
      />
      {errors[name] && (
        <p className="text-red-500 text-xs mt-1">{errors[name]?.message}</p>
      )}
    </div>
  );

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-blue-50 py-10 px-4">
      <div className="max-w-xl mx-auto">
        {/* Header */}
        <div className="mb-6">
          <div className="inline-flex items-center gap-2 text-slate-500 text-sm mb-4 hover:text-slate-700 transition-colors cursor-pointer">
            <ArrowLeft className="w-4 h-4" />
            <span>Back</span>
          </div>
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-blue-600 flex items-center justify-center">
              <FileText className="w-5 h-5 text-white" />
            </div>
            <div>
              <h1 className="text-xl font-bold text-slate-900">Submit a Complaint</h1>
              <p className="text-slate-500 text-sm">We review every complaint carefully</p>
            </div>
          </div>
        </div>

        {/* Form Card */}
        <motion.div
          initial={{ opacity: 0, y: 12 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-white rounded-2xl border border-slate-200 shadow-sm p-6 space-y-5"
        >
          <form onSubmit={handleSubmit(onSubmit)} className="space-y-5">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
              <Field label="Full Name" name="full_name" placeholder="Your full name" required />
              <Field label="Mobile Number" name="mobile" placeholder="10-digit mobile" required />
            </div>

            <Field label="Area / Location" name="area" placeholder="Village, Taluka, District" required />
            <Field label="Complaint Date" name="date" placeholder="" type="date" required />
            <Field label="Subject" name="subject" placeholder="Brief subject of complaint" required />

            <div>
              <label className="block text-sm font-medium text-slate-700 mb-1.5">
                Details <span className="text-red-500">*</span>
              </label>
              <textarea
                {...register('details')}
                placeholder="Describe your complaint in detail..."
                rows={5}
                className="w-full px-3.5 py-2.5 rounded-lg border border-slate-300 text-slate-900 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-blue-500/40 focus:border-blue-500 text-sm transition-all resize-none"
              />
              {errors.details && (
                <p className="text-red-500 text-xs mt-1">{errors.details.message}</p>
              )}
            </div>

            {/* File upload */}
            <div>
              <label className="block text-sm font-medium text-slate-700 mb-1.5">
                Attachments <span className="text-slate-400 font-normal">(optional, max 5 files)</span>
              </label>
              <label className="flex items-center gap-3 px-4 py-3 rounded-lg border-2 border-dashed border-slate-300 hover:border-blue-400 cursor-pointer transition-colors">
                <Upload className="w-4 h-4 text-slate-400" />
                <span className="text-sm text-slate-500">Click to upload photos, PDFs, videos</span>
                <input
                  type="file"
                  multiple
                  accept="image/*,application/pdf,video/mp4"
                  className="hidden"
                  onChange={(e) => {
                    const selected = Array.from(e.target.files || []);
                    setFiles((prev) => [...prev, ...selected].slice(0, 5));
                  }}
                />
              </label>
              {files.length > 0 && (
                <div className="mt-2 space-y-1">
                  {files.map((f, i) => (
                    <div key={i} className="flex items-center gap-2 bg-slate-50 rounded-lg px-3 py-2">
                      <Paperclip className="w-3.5 h-3.5 text-slate-400 flex-shrink-0" />
                      <span className="text-xs text-slate-600 flex-1 truncate">{f.name}</span>
                      <button type="button" onClick={() => removeFile(i)} className="text-slate-400 hover:text-red-500">
                        <X className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  ))}
                </div>
              )}
            </div>

            <button
              type="submit"
              disabled={isSubmitting}
              className="w-full flex items-center justify-center gap-2 py-3 px-6 rounded-xl bg-blue-600 hover:bg-blue-500 disabled:opacity-60 disabled:cursor-not-allowed text-white font-semibold text-sm transition-colors shadow-sm"
            >
              {isSubmitting ? (
                <>
                  <svg className="animate-spin w-4 h-4" fill="none" viewBox="0 0 24 24">
                    <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" />
                    <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8v8z" />
                  </svg>
                  Submitting…
                </>
              ) : (
                'Submit Complaint'
              )}
            </button>
          </form>
        </motion.div>

        <p className="text-center text-slate-400 text-xs mt-4">
          Your information is kept confidential and used only for processing your complaint.
        </p>
      </div>
    </div>
  );
}
