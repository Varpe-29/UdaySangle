'use client';

import { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { motion } from 'framer-motion';
import {
  Search, Filter, Eye, Trash2, ChevronLeft, ChevronRight,
  Plus, FileText, CheckCircle2, XCircle, Clock, AlertCircle,
} from 'lucide-react';
import { complaintsService } from '@/services/complaints.service';
import { useAuthStore, isMainAdmin } from '@/store/auth.store';
import toast from 'react-hot-toast';
import { formatDistanceToNow, format } from 'date-fns';
import clsx from 'clsx';

const STATUS_OPTIONS = ['ALL', 'PENDING', 'IN_PROGRESS', 'APPROVED', 'DONE', 'REJECTED'];

const STATUS_STYLES: Record<string, string> = {
  PENDING: 'bg-amber-500/10 text-amber-600 border-amber-500/20',
  IN_PROGRESS: 'bg-blue-500/10 text-blue-600 border-blue-500/20',
  APPROVED: 'bg-emerald-500/10 text-emerald-600 border-emerald-500/20',
  DONE: 'bg-green-500/10 text-green-700 border-green-500/20',
  REJECTED: 'bg-red-500/10 text-red-600 border-red-500/20',
};

const STATUS_ICONS: Record<string, any> = {
  PENDING: Clock, IN_PROGRESS: AlertCircle,
  APPROVED: CheckCircle2, DONE: CheckCircle2, REJECTED: XCircle,
};

export default function ComplaintsPage() {
  const { user } = useAuthStore();
  const qc = useQueryClient();
  const [page, setPage] = useState(1);
  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState('ALL');
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const [entryNote, setEntryNote] = useState('');

  const params = {
    page,
    limit: 10,
    ...(search && { search }),
    ...(statusFilter !== 'ALL' && { status: statusFilter }),
  };

  const { data, isLoading } = useQuery({
    queryKey: ['complaints', params],
    queryFn: () => complaintsService.getAll(params),
  });

  const { data: selectedComplaint } = useQuery({
    queryKey: ['complaint', selectedId],
    queryFn: () => complaintsService.getOne(selectedId!),
    enabled: !!selectedId,
  });

  const updateStatus = useMutation({
    mutationFn: ({ id, status }: { id: string; status: string }) =>
      complaintsService.updateStatus(id, status),
    onSuccess: () => {
      toast.success('Status updated');
      qc.invalidateQueries({ queryKey: ['complaints'] });
      qc.invalidateQueries({ queryKey: ['complaint', selectedId] });
    },
    onError: () => toast.error('Failed to update status'),
  });

  const addEntry = useMutation({
    mutationFn: ({ id, note }: { id: string; note: string }) =>
      complaintsService.addEntry(id, note),
    onSuccess: () => {
      toast.success('Note added');
      setEntryNote('');
      qc.invalidateQueries({ queryKey: ['complaint', selectedId] });
    },
    onError: () => toast.error('Failed to add note'),
  });

  const deleteComplaint = useMutation({
    mutationFn: complaintsService.remove,
    onSuccess: () => {
      toast.success('Complaint deleted');
      setSelectedId(null);
      qc.invalidateQueries({ queryKey: ['complaints'] });
    },
    onError: () => toast.error('Failed to delete'),
  });

  const complaints = data?.data || [];
  const meta = data?.meta || { total: 0, totalPages: 1 };
  const canEdit = isMainAdmin(user?.role);

  return (
    <div className="flex gap-4 h-full">
      {/* List Panel */}
      <div className={clsx('flex flex-col gap-4 min-w-0', selectedId ? 'flex-[0_0_55%]' : 'flex-1')}>
        {/* Header */}
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-xl font-bold text-foreground">Complaints</h1>
            <p className="text-muted-foreground text-sm">{meta.total} total complaints</p>
          </div>
        </div>

        {/* Filters */}
        <div className="flex gap-2 flex-wrap">
          <div className="relative flex-1 min-w-48">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
            <input
              type="text"
              placeholder="Search name, area, mobile…"
              value={search}
              onChange={(e) => { setSearch(e.target.value); setPage(1); }}
              className="w-full pl-9 pr-3 py-2 text-sm rounded-lg border border-border bg-card focus:outline-none focus:ring-2 focus:ring-primary/30"
            />
          </div>
          <select
            value={statusFilter}
            onChange={(e) => { setStatusFilter(e.target.value); setPage(1); }}
            className="px-3 py-2 text-sm rounded-lg border border-border bg-card focus:outline-none focus:ring-2 focus:ring-primary/30"
          >
            {STATUS_OPTIONS.map((s) => <option key={s} value={s}>{s === 'ALL' ? 'All Status' : s}</option>)}
          </select>
        </div>

        {/* Table */}
        <div className="bg-card border border-border rounded-xl overflow-hidden flex-1">
          {isLoading ? (
            <div className="space-y-px">
              {Array.from({ length: 8 }).map((_, i) => (
                <div key={i} className="h-14 bg-muted/30 animate-pulse" />
              ))}
            </div>
          ) : complaints.length === 0 ? (
            <div className="flex flex-col items-center justify-center py-16 text-muted-foreground">
              <FileText className="w-10 h-10 mb-3 opacity-30" />
              <p className="font-medium">No complaints found</p>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr className="border-b border-border bg-muted/30">
                    {['Name', 'Area', 'Subject', 'Date', 'Status', ''].map((h) => (
                      <th key={h} className="text-left text-xs font-medium text-muted-foreground px-4 py-2.5 first:pl-5 last:pr-5">
                        {h}
                      </th>
                    ))}
                  </tr>
                </thead>
                <tbody className="divide-y divide-border">
                  {complaints.map((c: any) => {
                    const Icon = STATUS_ICONS[c.status] || Clock;
                    return (
                      <tr
                        key={c.id}
                        className={clsx(
                          'hover:bg-muted/20 cursor-pointer transition-colors',
                          selectedId === c.id && 'bg-primary/5',
                        )}
                        onClick={() => setSelectedId(c.id === selectedId ? null : c.id)}
                      >
                        <td className="px-4 py-3 pl-5">
                          <p className="font-medium text-sm text-foreground truncate max-w-28">{c.fullName}</p>
                          <p className="text-xs text-muted-foreground">{c.mobile}</p>
                        </td>
                        <td className="px-4 py-3 text-sm text-muted-foreground truncate max-w-28">{c.area}</td>
                        <td className="px-4 py-3 text-sm text-foreground truncate max-w-40">{c.subject}</td>
                        <td className="px-4 py-3 text-xs text-muted-foreground whitespace-nowrap">
                          {format(new Date(c.complaintDate), 'dd MMM yy')}
                        </td>
                        <td className="px-4 py-3">
                          <span className={clsx('inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-xs font-medium border', STATUS_STYLES[c.status])}>
                            <Icon className="w-3 h-3" />
                            {c.status}
                          </span>
                        </td>
                        <td className="px-4 py-3 pr-5">
                          <button className="text-muted-foreground hover:text-foreground">
                            <Eye className="w-4 h-4" />
                          </button>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          )}
        </div>

        {/* Pagination */}
        {meta.totalPages > 1 && (
          <div className="flex items-center justify-between">
            <p className="text-xs text-muted-foreground">
              Page {page} of {meta.totalPages}
            </p>
            <div className="flex gap-1">
              <button
                onClick={() => setPage((p) => Math.max(1, p - 1))}
                disabled={page === 1}
                className="p-1.5 rounded-lg border border-border hover:bg-muted disabled:opacity-40 disabled:cursor-not-allowed"
              >
                <ChevronLeft className="w-4 h-4" />
              </button>
              <button
                onClick={() => setPage((p) => Math.min(meta.totalPages, p + 1))}
                disabled={page === meta.totalPages}
                className="p-1.5 rounded-lg border border-border hover:bg-muted disabled:opacity-40 disabled:cursor-not-allowed"
              >
                <ChevronRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        )}
      </div>

      {/* Detail Panel */}
      {selectedId && selectedComplaint && (
        <motion.div
          initial={{ opacity: 0, x: 16 }}
          animate={{ opacity: 1, x: 0 }}
          exit={{ opacity: 0, x: 16 }}
          className="flex-[0_0_42%] bg-card border border-border rounded-xl overflow-y-auto"
        >
          <div className="p-5 space-y-4">
            {/* Detail header */}
            <div className="flex items-start justify-between">
              <div>
                <h2 className="font-semibold text-foreground">{selectedComplaint.fullName}</h2>
                <p className="text-sm text-muted-foreground">{selectedComplaint.mobile} · {selectedComplaint.area}</p>
              </div>
              {canEdit && (
                <button
                  onClick={() => deleteComplaint.mutate(selectedId)}
                  className="text-muted-foreground hover:text-red-500 transition-colors p-1"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              )}
            </div>

            {/* Status update */}
            {canEdit && (
              <div>
                <p className="text-xs font-medium text-muted-foreground mb-1.5">Update Status</p>
                <div className="flex flex-wrap gap-1.5">
                  {['PENDING', 'IN_PROGRESS', 'APPROVED', 'DONE', 'REJECTED'].map((s) => (
                    <button
                      key={s}
                      onClick={() => updateStatus.mutate({ id: selectedId, status: s })}
                      className={clsx(
                        'px-2.5 py-1 text-xs rounded-full border font-medium transition-all',
                        selectedComplaint.status === s
                          ? STATUS_STYLES[s]
                          : 'border-border text-muted-foreground hover:border-primary/50',
                      )}
                    >
                      {s}
                    </button>
                  ))}
                </div>
              </div>
            )}

            {/* Subject & Details */}
            <div>
              <p className="text-xs font-medium text-muted-foreground mb-1">Subject</p>
              <p className="text-sm font-medium text-foreground">{selectedComplaint.subject}</p>
            </div>
            <div>
              <p className="text-xs font-medium text-muted-foreground mb-1">Details</p>
              <p className="text-sm text-foreground leading-relaxed">{selectedComplaint.details}</p>
            </div>

            {/* Media */}
            {selectedComplaint.mediaFiles?.length > 0 && (
              <div>
                <p className="text-xs font-medium text-muted-foreground mb-2">Attachments</p>
                <div className="flex flex-wrap gap-2">
                  {selectedComplaint.mediaFiles.map((url: string, i: number) => (
                    <a
                      key={i}
                      href={url}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-xs text-blue-500 hover:underline"
                    >
                      File {i + 1}
                    </a>
                  ))}
                </div>
              </div>
            )}

            {/* Entries / Notes */}
            {selectedComplaint.entries?.length > 0 && (
              <div>
                <p className="text-xs font-medium text-muted-foreground mb-2">Activity Notes</p>
                <div className="space-y-2">
                  {selectedComplaint.entries.map((e: any) => (
                    <div key={e.id} className="bg-muted/30 rounded-lg p-3">
                      <p className="text-sm text-foreground">{e.note}</p>
                      <p className="text-xs text-muted-foreground mt-1">
                        {e.addedBy} · {formatDistanceToNow(new Date(e.createdAt), { addSuffix: true })}
                      </p>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Add note */}
            <div>
              <p className="text-xs font-medium text-muted-foreground mb-1.5">Add Note</p>
              <textarea
                value={entryNote}
                onChange={(e) => setEntryNote(e.target.value)}
                placeholder="Enter note or update…"
                rows={3}
                className="w-full px-3 py-2 text-sm rounded-lg border border-border bg-background focus:outline-none focus:ring-2 focus:ring-primary/30 resize-none"
              />
              <button
                onClick={() => entryNote.trim() && addEntry.mutate({ id: selectedId, note: entryNote.trim() })}
                disabled={!entryNote.trim() || addEntry.isPending}
                className="mt-2 px-4 py-1.5 text-sm bg-primary text-primary-foreground rounded-lg hover:bg-primary/90 disabled:opacity-50 disabled:cursor-not-allowed"
              >
                {addEntry.isPending ? 'Adding…' : 'Add Note'}
              </button>
            </div>
          </div>
        </motion.div>
      )}
    </div>
  );
}
