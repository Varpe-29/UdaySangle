// src/app/page.tsx
import { redirect } from 'next/navigation';

export default function RootPage() {
  // Redirect directly to dashboard (middleware handles auth check)
  redirect('/dashboard');
}
