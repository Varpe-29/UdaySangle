'use client';

import { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { motion } from 'framer-motion';
import { Search, Calendar, ChevronLeft, ChevronRight, Eye, Trash2, CheckCircle2, XCircle, Clock } from 'lucide-react';
import { appointmentsService } from '@/services/complaints.service';
import { useAuthStore, isMainAdmin } from '@/store/auth.store';
import toast from 'react-hot-toast';
import { format } from 'date-fns';
import clsx from 'clsx';

const STATUS_STYLES: Record<string, string> = {
  PENDING: 'bg-amber-500/10 text-amber-600 border-amber-500/20',
  CONFIRMED: 'bg-emerald-500/10 text-emerald-600 border-emerald-500/20',
  CANCELLED: 'bg-red-500/10 text-red-600 border-red-500/20',
  COMPLETED: 'bg-blue-500/10 text-blue-600 border-blue-500/20',
};

export default function AppointmentsPage() {
  const { user } = useAuthStore();
  const qc = useQueryClient();
  const [page, setPage] = useState(1);
  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState('ALL');
  const [selectedId, setSelectedId] = useState<string | null>(null);

  const params = {
    page, limit: 10,
    ...(search && { search }),
    ...(statusFilter !== 'ALL' && { status: statusFilter }),
    sortBy: 'appointmentDate', sortOrder: 'asc',
  };

  const { data, isLoading } = useQuery({
    queryKey: ['appointments', params],
    queryFn: () => appointmentsService.getAll(params),
  });

  const { data: selected } = useQuery({
    queryKey: ['appointment', selectedId],
    queryFn: () => appointmentsService.getOne(selectedId!),
    enabled: !!selectedId,
  });

  const updateStatus = useMutation({
    mutationFn: ({ id, status }: { id: string; status: string }) =>
      appointmentsService.updateStatus(id, status),
    onSuccess: () => {
      toast.success('Status updated');
      qc.invalidateQueries({ queryKey: ['appointments'] });
      qc.invalidateQueries({ queryKey: ['appointment', selectedId] });
    },
  });

  const deleteAppt = useMutation({
    mutationFn: appointmentsService.remove,
    onSuccess: () => {
      toast.success('Appointment deleted');
      setSelectedId(null);
      qc.invalidateQueries({ queryKey: ['appointments'] });
    },
  });

  const appointments = data?.data || [];
  const meta = data?.meta || { total: 0, totalPages: 1 };
  const canEdit = isMainAdmin(user?.role);

  return (
    <div className="flex gap-4 h-full">
      <div className={clsx('flex flex-col gap-4 min-w-0', selectedId ? 'flex-[0_0_55%]' : 'flex-1')}>
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-xl font-bold text-foreground">Appointments</h1>
            <p className="text-muted-foreground text-sm">{meta.total} total</p>
          </div>
        </div>

        <div className="flex gap-2 flex-wrap">
          <div className="relative flex-1 min-w-48">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
            <input
              type="text" placeholder="Search name, area, mobile…"
              value={search} onChange={(e) => { setSearch(e.target.value); setPage(1); }}
              className="w-full pl-9 pr-3 py-2 text-sm rounded-lg border border-border bg-card focus:outline-none focus:ring-2 focus:ring-primary/30"
            />
          </div>
          <select
            value={statusFilter} onChange={(e) => { setStatusFilter(e.target.value); setPage(1); }}
            className="px-3 py-2 text-sm rounded-lg border border-border bg-card focus:outline-none"
          >
            {['ALL', 'PENDING', 'CONFIRMED', 'CANCELLED', 'COMPLETED'].map((s) => (
              <option key={s} value={s}>{s === 'ALL' ? 'All Status' : s}</option>
            ))}
          </select>
        </div>

        <div className="bg-card border border-border rounded-xl overflow-hidden flex-1">
          {isLoading ? (
            <div className="space-y-px">{Array.from({ length: 8 }).map((_, i) => <div key={i} className="h-14 bg-muted/30 animate-pulse" />)}</div>
          ) : appointments.length === 0 ? (
            <div className="flex flex-col items-center justify-center py-16 text-muted-foreground">
              <Calendar className="w-10 h-10 mb-3 opacity-30" />
              <p>No appointments found</p>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr className="border-b border-border bg-muted/30">
                    {['Name', 'Area', 'Date & Time', 'Status', ''].map((h) => (
                      <th key={h} className="text-left text-xs font-medium text-muted-foreground px-4 py-2.5">{h}</th>
                    ))}
                  </tr>
                </thead>
                <tbody className="divide-y divide-border">
                  {appointments.map((a: any) => (
                    <tr
                      key={a.id}
                      className={clsx('hover:bg-muted/20 cursor-pointer transition-colors', selectedId === a.id && 'bg-primary/5')}
                      onClick={() => setSelectedId(a.id === selectedId ? null : a.id)}
                    >
                      <td className="px-4 py-3">
                        <p className="font-medium text-sm text-foreground">{a.fullName}</p>
                        <p className="text-xs text-muted-foreground">{a.mobile}</p>
                      </td>
                      <td className="px-4 py-3 text-sm text-muted-foreground">{a.area}</td>
                      <td className="px-4 py-3 text-sm text-foreground whitespace-nowrap">
                        {format(new Date(a.appointmentDate), 'dd MMM yyyy')}
                        <span className="text-muted-foreground ml-1">{a.appointmentTime}</span>
                      </td>
                      <td className="px-4 py-3">
                        <span className={clsx('inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium border', STATUS_STYLES[a.status])}>
                          {a.status}
                        </span>
                      </td>
                      <td className="px-4 py-3"><Eye className="w-4 h-4 text-muted-foreground" /></td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>

        {meta.totalPages > 1 && (
          <div className="flex items-center justify-between">
            <p className="text-xs text-muted-foreground">Page {page} of {meta.totalPages}</p>
            <div className="flex gap-1">
              <button onClick={() => setPage((p) => Math.max(1, p - 1))} disabled={page === 1} className="p-1.5 rounded-lg border border-border hover:bg-muted disabled:opacity-40">
                <ChevronLeft className="w-4 h-4" />
              </button>
              <button onClick={() => setPage((p) => Math.min(meta.totalPages, p + 1))} disabled={page === meta.totalPages} className="p-1.5 rounded-lg border border-border hover:bg-muted disabled:opacity-40">
                <ChevronRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        )}
      </div>

      {selectedId && selected && (
        <motion.div initial={{ opacity: 0, x: 16 }} animate={{ opacity: 1, x: 0 }} className="flex-[0_0_42%] bg-card border border-border rounded-xl overflow-y-auto">
          <div className="p-5 space-y-4">
            <div className="flex items-start justify-between">
              <div>
                <h2 className="font-semibold text-foreground">{selected.fullName}</h2>
                <p className="text-sm text-muted-foreground">{selected.mobile} · {selected.area}</p>
              </div>
              {canEdit && (
                <button onClick={() => deleteAppt.mutate(selectedId)} className="text-muted-foreground hover:text-red-500 p-1">
                  <Trash2 className="w-4 h-4" />
                </button>
              )}
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <p className="text-xs text-muted-foreground">Date</p>
                <p className="text-sm font-medium">{format(new Date(selected.appointmentDate), 'dd MMMM yyyy')}</p>
              </div>
              <div>
                <p className="text-xs text-muted-foreground">Time</p>
                <p className="text-sm font-medium">{selected.appointmentTime}</p>
              </div>
            </div>

            <div>
              <p className="text-xs text-muted-foreground mb-1">Purpose</p>
              <p className="text-sm text-foreground leading-relaxed">{selected.purpose}</p>
            </div>

            {canEdit && (
              <div>
                <p className="text-xs font-medium text-muted-foreground mb-2">Update Status</p>
                <div className="flex flex-wrap gap-2">
                  {['PENDING', 'CONFIRMED', 'CANCELLED', 'COMPLETED'].map((s) => (
                    <button
                      key={s}
                      onClick={() => updateStatus.mutate({ id: selectedId, status: s })}
                      className={clsx(
                        'px-3 py-1.5 text-xs rounded-full border font-medium transition-all',
                        selected.status === s ? STATUS_STYLES[s] : 'border-border text-muted-foreground hover:border-primary/50',
                      )}
                    >
                      {s}
                    </button>
                  ))}
                </div>
              </div>
            )}

            {selected.notes && (
              <div>
                <p className="text-xs text-muted-foreground mb-1">Notes</p>
                <p className="text-sm bg-muted/30 rounded-lg p-3">{selected.notes}</p>
              </div>
            )}
          </div>
        </motion.div>
      )}
    </div>
  );
}
