'use client';

import { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { motion, AnimatePresence } from 'framer-motion';
import { Plus, Trash2, Mail, X, ChevronDown, ChevronUp } from 'lucide-react';
import { lettersService } from '@/services/complaints.service';
import { useAuthStore, isMainAdmin } from '@/store/auth.store';
import toast from 'react-hot-toast';
import { format } from 'date-fns';

export default function LettersPage() {
  const { user } = useAuthStore();
  const qc = useQueryClient();
  const [showForm, setShowForm] = useState(false);
  const [expandedId, setExpandedId] = useState<string | null>(null);
  const [form, setForm] = useState({ title: '', content: '', recipient: '' });
  const [files, setFiles] = useState<File[]>([]);

  const { data: letters = [], isLoading } = useQuery({
    queryKey: ['letters'],
    queryFn: lettersService.getAll,
  });

  const createLetter = useMutation({
    mutationFn: (fd: FormData) => lettersService.create(fd),
    onSuccess: () => {
      toast.success('Letter created!');
      setForm({ title: '', content: '', recipient: '' });
      setFiles([]); setShowForm(false);
      qc.invalidateQueries({ queryKey: ['letters'] });
    },
    onError: () => toast.error('Failed to create letter'),
  });

  const deleteLetter = useMutation({
    mutationFn: lettersService.remove,
    onSuccess: () => { toast.success('Letter deleted'); qc.invalidateQueries({ queryKey: ['letters'] }); },
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const fd = new FormData();
    Object.entries(form).forEach(([k, v]) => v && fd.append(k, v));
    files.forEach((f) => fd.append('files', f));
    createLetter.mutate(fd);
  };

  const canDelete = isMainAdmin(user?.role);

  return (
    <div className="space-y-5 max-w-3xl">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-xl font-bold text-foreground">Letters</h1>
          <p className="text-muted-foreground text-sm">{letters.length} letters</p>
        </div>
        <button
          onClick={() => setShowForm(!showForm)}
          className="flex items-center gap-2 px-4 py-2 text-sm bg-primary text-primary-foreground rounded-lg hover:bg-primary/90 transition-colors"
        >
          {showForm ? <X className="w-4 h-4" /> : <Plus className="w-4 h-4" />}
          {showForm ? 'Cancel' : 'New Letter'}
        </button>
      </div>

      <AnimatePresence>
        {showForm && (
          <motion.form
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            onSubmit={handleSubmit}
            className="bg-card border border-border rounded-xl p-5 space-y-4 overflow-hidden"
          >
            <h2 className="font-semibold text-sm text-foreground">Compose Letter</h2>
            {[
              { key: 'title', label: 'Title *', placeholder: 'Letter title…', required: true },
              { key: 'recipient', label: 'Recipient', placeholder: 'To whom…' },
            ].map(({ key, label, placeholder, required }) => (
              <div key={key}>
                <label className="text-xs text-muted-foreground mb-1 block">{label}</label>
                <input
                  value={(form as any)[key]}
                  onChange={(e) => setForm((p) => ({ ...p, [key]: e.target.value }))}
                  placeholder={placeholder}
                  required={required}
                  className="w-full px-3 py-2 text-sm rounded-lg border border-border bg-background focus:outline-none focus:ring-2 focus:ring-primary/30"
                />
              </div>
            ))}
            <div>
              <label className="text-xs text-muted-foreground mb-1 block">Content *</label>
              <textarea
                value={form.content}
                onChange={(e) => setForm((p) => ({ ...p, content: e.target.value }))}
                placeholder="Letter content…" rows={6} required
                className="w-full px-3 py-2 text-sm rounded-lg border border-border bg-background focus:outline-none focus:ring-2 focus:ring-primary/30 resize-none"
              />
            </div>
            <div>
              <label className="text-xs text-muted-foreground mb-1 block">Attachments</label>
              <input type="file" multiple accept="image/*,application/pdf" onChange={(e) => setFiles(Array.from(e.target.files || []))} className="text-xs text-muted-foreground" />
            </div>
            <button type="submit" disabled={createLetter.isPending || !form.title || !form.content} className="px-4 py-2 text-sm bg-primary text-primary-foreground rounded-lg hover:bg-primary/90 disabled:opacity-50">
              {createLetter.isPending ? 'Creating…' : 'Create Letter'}
            </button>
          </motion.form>
        )}
      </AnimatePresence>

      {isLoading ? (
        <div className="space-y-3">{Array.from({ length: 4 }).map((_, i) => <div key={i} className="h-20 bg-card border border-border rounded-xl animate-pulse" />)}</div>
      ) : letters.length === 0 ? (
        <div className="flex flex-col items-center justify-center py-20 text-muted-foreground">
          <Mail className="w-10 h-10 mb-3 opacity-30" />
          <p>No letters yet</p>
        </div>
      ) : (
        <div className="space-y-3">
          {letters.map((letter: any) => (
            <div key={letter.id} className="bg-card border border-border rounded-xl overflow-hidden">
              <div
                className="flex items-center justify-between px-5 py-4 cursor-pointer hover:bg-muted/10"
                onClick={() => setExpandedId(expandedId === letter.id ? null : letter.id)}
              >
                <div className="flex items-center gap-3 min-w-0">
                  <Mail className="w-4 h-4 text-indigo-500 flex-shrink-0" />
                  <div className="min-w-0">
                    <p className="font-medium text-sm text-foreground truncate">{letter.title}</p>
                    <p className="text-xs text-muted-foreground">
                      {letter.recipient && `To: ${letter.recipient} · `}
                      {letter.createdBy} · {format(new Date(letter.createdAt), 'dd MMM yyyy')}
                    </p>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  {canDelete && (
                    <button onClick={(e) => { e.stopPropagation(); deleteLetter.mutate(letter.id); }} className="text-muted-foreground hover:text-red-500 p-1">
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  )}
                  {expandedId === letter.id ? <ChevronUp className="w-4 h-4 text-muted-foreground" /> : <ChevronDown className="w-4 h-4 text-muted-foreground" />}
                </div>
              </div>
              <AnimatePresence>
                {expandedId === letter.id && (
                  <motion.div initial={{ height: 0 }} animate={{ height: 'auto' }} exit={{ height: 0 }} className="overflow-hidden border-t border-border">
                    <div className="px-5 py-4">
                      <p className="text-sm text-foreground leading-relaxed whitespace-pre-wrap">{letter.content}</p>
                      {letter.mediaFiles?.length > 0 && (
                        <div className="mt-3 flex gap-2 flex-wrap">
                          {letter.mediaFiles.map((url: string, i: number) => (
                            <a key={i} href={url} target="_blank" rel="noreferrer" className="text-xs text-blue-500 hover:underline">Attachment {i + 1}</a>
                          ))}
                        </div>
                      )}
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
