'use client';

import { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { motion, AnimatePresence } from 'framer-motion';
import { Plus, Trash2, Bell, X, Image, Paperclip } from 'lucide-react';
import { noticesService } from '@/services/complaints.service';
import { useAuthStore, isMainAdmin } from '@/store/auth.store';
import toast from 'react-hot-toast';
import { formatDistanceToNow } from 'date-fns';

export default function NoticesPage() {
  const { user } = useAuthStore();
  const qc = useQueryClient();
  const [showForm, setShowForm] = useState(false);
  const [title, setTitle] = useState('');
  const [content, setContent] = useState('');
  const [files, setFiles] = useState<File[]>([]);

  const { data: notices = [], isLoading } = useQuery({
    queryKey: ['notices'],
    queryFn: noticesService.getAll,
  });

  const createNotice = useMutation({
    mutationFn: (fd: FormData) => noticesService.create(fd),
    onSuccess: () => {
      toast.success('Notice posted!');
      setTitle(''); setContent(''); setFiles([]); setShowForm(false);
      qc.invalidateQueries({ queryKey: ['notices'] });
    },
    onError: () => toast.error('Failed to post notice'),
  });

  const deleteNotice = useMutation({
    mutationFn: noticesService.remove,
    onSuccess: () => { toast.success('Notice deleted'); qc.invalidateQueries({ queryKey: ['notices'] }); },
    onError: () => toast.error('Failed to delete'),
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim()) return;
    const fd = new FormData();
    fd.append('title', title.trim());
    fd.append('content', content.trim());
    files.forEach((f) => fd.append('files', f));
    createNotice.mutate(fd);
  };

  const canDelete = isMainAdmin(user?.role);

  return (
    <div className="space-y-5 max-w-3xl">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-xl font-bold text-foreground">Notice Board</h1>
          <p className="text-muted-foreground text-sm">{notices.length} notices</p>
        </div>
        <button
          onClick={() => setShowForm(!showForm)}
          className="flex items-center gap-2 px-4 py-2 text-sm bg-primary text-primary-foreground rounded-lg hover:bg-primary/90 transition-colors"
        >
          {showForm ? <X className="w-4 h-4" /> : <Plus className="w-4 h-4" />}
          {showForm ? 'Cancel' : 'New Notice'}
        </button>
      </div>

      {/* Create form */}
      <AnimatePresence>
        {showForm && (
          <motion.form
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            onSubmit={handleSubmit}
            className="bg-card border border-border rounded-xl p-5 space-y-4 overflow-hidden"
          >
            <h2 className="font-semibold text-sm text-foreground">Post New Notice</h2>
            <div>
              <label className="text-xs text-muted-foreground mb-1 block">Title *</label>
              <input
                value={title} onChange={(e) => setTitle(e.target.value)}
                placeholder="Notice title…" required
                className="w-full px-3 py-2 text-sm rounded-lg border border-border bg-background focus:outline-none focus:ring-2 focus:ring-primary/30"
              />
            </div>
            <div>
              <label className="text-xs text-muted-foreground mb-1 block">Content</label>
              <textarea
                value={content} onChange={(e) => setContent(e.target.value)}
                placeholder="Notice details…" rows={4}
                className="w-full px-3 py-2 text-sm rounded-lg border border-border bg-background focus:outline-none focus:ring-2 focus:ring-primary/30 resize-none"
              />
            </div>
            <div>
              <label className="text-xs text-muted-foreground mb-1 block">Attachments (optional)</label>
              <input
                type="file" multiple accept="image/*,application/pdf"
                onChange={(e) => setFiles(Array.from(e.target.files || []))}
                className="text-xs text-muted-foreground"
              />
            </div>
            <button
              type="submit" disabled={createNotice.isPending || !title.trim()}
              className="px-4 py-2 text-sm bg-primary text-primary-foreground rounded-lg hover:bg-primary/90 disabled:opacity-50"
            >
              {createNotice.isPending ? 'Posting…' : 'Post Notice'}
            </button>
          </motion.form>
        )}
      </AnimatePresence>

      {/* Notices list */}
      {isLoading ? (
        <div className="space-y-3">
          {Array.from({ length: 4 }).map((_, i) => <div key={i} className="h-24 bg-card border border-border rounded-xl animate-pulse" />)}
        </div>
      ) : notices.length === 0 ? (
        <div className="flex flex-col items-center justify-center py-20 text-muted-foreground">
          <Bell className="w-10 h-10 mb-3 opacity-30" />
          <p>No notices posted yet</p>
        </div>
      ) : (
        <div className="space-y-3">
          {notices.map((notice: any) => (
            <motion.div
              key={notice.id}
              initial={{ opacity: 0, y: 8 }}
              animate={{ opacity: 1, y: 0 }}
              className="bg-card border border-border rounded-xl p-5"
            >
              <div className="flex items-start justify-between gap-3">
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 mb-1">
                    <Bell className="w-4 h-4 text-blue-500 flex-shrink-0" />
                    <h3 className="font-semibold text-foreground text-sm">{notice.title}</h3>
                  </div>
                  {notice.content && <p className="text-sm text-muted-foreground leading-relaxed mt-1">{notice.content}</p>}
                  {notice.mediaFiles?.length > 0 && (
                    <div className="flex items-center gap-2 mt-2">
                      <Paperclip className="w-3 h-3 text-muted-foreground" />
                      {notice.mediaFiles.map((url: string, i: number) => (
                        <a key={i} href={url} target="_blank" rel="noreferrer" className="text-xs text-blue-500 hover:underline">
                          Attachment {i + 1}
                        </a>
                      ))}
                    </div>
                  )}
                  <p className="text-xs text-muted-foreground mt-2">
                    Posted by {notice.postedBy} · {formatDistanceToNow(new Date(notice.createdAt), { addSuffix: true })}
                  </p>
                </div>
                {canDelete && (
                  <button onClick={() => deleteNotice.mutate(notice.id)} className="text-muted-foreground hover:text-red-500 transition-colors flex-shrink-0">
                    <Trash2 className="w-4 h-4" />
                  </button>
                )}
              </div>
            </motion.div>
          ))}
        </div>
      )}
    </div>
  );
}
