// src/types/index.ts

export type Role = 'SUPER_ADMIN' | 'MAIN_ADMIN' | 'STAFF_ADMIN';

export type ComplaintStatus = 'PENDING' | 'IN_PROGRESS' | 'APPROVED' | 'DONE' | 'REJECTED';
export type AppointmentStatus = 'PENDING' | 'CONFIRMED' | 'CANCELLED' | 'COMPLETED';

export interface PaginatedResponse<T> {
  data: T[];
  meta: {
    total: number;
    page: number;
    limit: number;
    totalPages: number;
  };
}

export interface ApiResponse<T = unknown> {
  success: boolean;
  data: T;
  timestamp: string;
}

export interface Complaint {
  id: string;
  fullName: string;
  mobile: string;
  area: string;
  subject: string;
  details: string;
  status: ComplaintStatus;
  mediaFiles: string[];
  complaintDate: string;
  resolvedAt: string | null;
  createdAt: string;
  updatedAt: string;
  entries: ComplaintEntry[];
}

export interface ComplaintEntry {
  id: string;
  note: string;
  addedBy: string;
  createdAt: string;
}

export interface Appointment {
  id: string;
  fullName: string;
  mobile: string;
  area: string;
  purpose: string;
  appointmentDate: string;
  appointmentTime: string;
  status: AppointmentStatus;
  notes: string | null;
  mediaFiles: string[];
  createdAt: string;
}

export interface Notice {
  id: string;
  title: string;
  content: string;
  mediaFiles: string[];
  isPublic: boolean;
  postedBy: string;
  createdAt: string;
}

export interface Letter {
  id: string;
  title: string;
  content: string;
  recipient: string | null;
  createdBy: string;
  mediaFiles: string[];
  createdAt: string;
}

export interface AdminUser {
  id: string;
  username: string;
  email: string | null;
  role: Role;
  isActive: boolean;
  isLocked: boolean;
  lastLoginAt: string | null;
  lastLoginIp: string | null;
  createdAt: string;
}

export interface ActivityLog {
  id: string;
  userId: string;
  action: string;
  entity: string;
  entityId: string | null;
  ipAddress: string | null;
  createdAt: string;
  user: { username: string; role: Role };
}

export interface AnalyticsOverview {
  totalComplaints: number;
  pendingComplaints: number;
  doneComplaints: number;
  totalAppointments: number;
  pendingAppointments: number;
  confirmedAppointments: number;
  totalNotices: number;
  totalUsers: number;
  totalLetters: number;
}
