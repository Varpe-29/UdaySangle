// src/store/auth.store.ts
import { create } from 'zustand';
import { persist, createJSONStorage } from 'zustand/middleware';

export interface AuthUser {
  id: string;
  username: string;
  role: 'SUPER_ADMIN' | 'MAIN_ADMIN' | 'STAFF_ADMIN';
  email?: string;
}

interface AuthState {
  user: AuthUser | null;
  accessToken: string | null;
  isAuthenticated: boolean;
  setAuth: (user: AuthUser, token: string) => void;
  setAccessToken: (token: string) => void;
  logout: () => void;
}

export const useAuthStore = create<AuthState>()(
  persist(
    (set) => ({
      user: null,
      accessToken: null,
      isAuthenticated: false,

      setAuth: (user, accessToken) =>
        set({ user, accessToken, isAuthenticated: true }),

      setAccessToken: (accessToken) =>
        set({ accessToken }),

      logout: () =>
        set({ user: null, accessToken: null, isAuthenticated: false }),
    }),
    {
      name: 'auth-storage',
      storage: createJSONStorage(() => sessionStorage), // sessionStorage — clears on tab close
      partialize: (state) => ({
        user: state.user,
        accessToken: state.accessToken,
        isAuthenticated: state.isAuthenticated,
      }),
    },
  ),
);

// ── Role helpers ─────────────────────────────────────────────
export const isSuperAdmin = (role?: string) => role === 'SUPER_ADMIN';
export const isMainAdmin = (role?: string) => role === 'SUPER_ADMIN' || role === 'MAIN_ADMIN';
export const isStaff = (role?: string) =>
  role === 'SUPER_ADMIN' || role === 'MAIN_ADMIN' || role === 'STAFF_ADMIN';
