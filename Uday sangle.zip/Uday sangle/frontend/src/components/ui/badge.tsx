// src/components/ui/badge.tsx
import { HTMLAttributes } from 'react';
import { cn } from '@/lib/utils';

interface BadgeProps extends HTMLAttributes<HTMLSpanElement> {
  variant?: 'default' | 'success' | 'warning' | 'danger' | 'info' | 'outline';
}

const BADGE_VARIANTS = {
  default: 'bg-secondary text-secondary-foreground',
  success: 'bg-emerald-500/10 text-emerald-700 border border-emerald-500/20',
  warning: 'bg-amber-500/10 text-amber-700 border border-amber-500/20',
  danger: 'bg-red-500/10 text-red-700 border border-red-500/20',
  info: 'bg-blue-500/10 text-blue-700 border border-blue-500/20',
  outline: 'border border-border text-foreground',
};

export function Badge({ className, variant = 'default', ...props }: BadgeProps) {
  return (
    <span
      className={cn(
        'inline-flex items-center rounded-full px-2.5 py-0.5 text-xs font-medium',
        BADGE_VARIANTS[variant],
        className,
      )}
      {...props}
    />
  );
}

// ── Skeleton ──────────────────────────────────────────────────
export function Skeleton({ className, ...props }: HTMLAttributes<HTMLDivElement>) {
  return (
    <div
      className={cn('animate-pulse rounded-md bg-muted', className)}
      {...props}
    />
  );
}

// ── Empty state ───────────────────────────────────────────────
interface EmptyStateProps {
  icon?: React.ReactNode;
  title: string;
  description?: string;
  action?: React.ReactNode;
}

export function EmptyState({ icon, title, description, action }: EmptyStateProps) {
  return (
    <div className="flex flex-col items-center justify-center py-16 px-4 text-center">
      {icon && (
        <div className="mb-4 text-muted-foreground opacity-40">{icon}</div>
      )}
      <p className="font-medium text-foreground">{title}</p>
      {description && (
        <p className="text-sm text-muted-foreground mt-1 max-w-xs">{description}</p>
      )}
      {action && <div className="mt-4">{action}</div>}
    </div>
  );
}

// ── Page Header ───────────────────────────────────────────────
interface PageHeaderProps {
  title: string;
  subtitle?: string;
  actions?: React.ReactNode;
}

export function PageHeader({ title, subtitle, actions }: PageHeaderProps) {
  return (
    <div className="flex items-start justify-between gap-4 mb-6">
      <div>
        <h1 className="text-xl font-bold text-foreground">{title}</h1>
        {subtitle && (
          <p className="text-sm text-muted-foreground mt-0.5">{subtitle}</p>
        )}
      </div>
      {actions && <div className="flex items-center gap-2 flex-shrink-0">{actions}</div>}
    </div>
  );
}

// ── Card ──────────────────────────────────────────────────────
interface CardProps extends HTMLAttributes<HTMLDivElement> {
  padding?: 'sm' | 'md' | 'lg';
}

const CARD_PADDING = { sm: 'p-3', md: 'p-5', lg: 'p-7' };

export function Card({ className, padding = 'md', ...props }: CardProps) {
  return (
    <div
      className={cn(
        'bg-card border border-border rounded-xl',
        CARD_PADDING[padding],
        className,
      )}
      {...props}
    />
  );
}

// ── Status Badge for Complaints ────────────────────────────────
const COMPLAINT_BADGE: Record<string, string> = {
  PENDING: 'warning',
  IN_PROGRESS: 'info',
  APPROVED: 'success',
  DONE: 'success',
  REJECTED: 'danger',
};

const APPOINTMENT_BADGE: Record<string, string> = {
  PENDING: 'warning',
  CONFIRMED: 'success',
  CANCELLED: 'danger',
  COMPLETED: 'info',
};

export function ComplaintStatusBadge({ status }: { status: string }) {
  return (
    <Badge variant={(COMPLAINT_BADGE[status] || 'default') as any}>
      {status.replace('_', ' ')}
    </Badge>
  );
}

export function AppointmentStatusBadge({ status }: { status: string }) {
  return (
    <Badge variant={(APPOINTMENT_BADGE[status] || 'default') as any}>
      {status}
    </Badge>
  );
}
