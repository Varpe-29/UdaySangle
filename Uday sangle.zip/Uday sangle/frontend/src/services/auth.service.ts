// src/services/auth.service.ts
import api from '@/lib/api';

export interface LoginPayload {
  username: string;
  password: string;
}

export interface LoginResponse {
  accessToken: string;
  user: {
    id: string;
    username: string;
    role: string;
    email?: string;
  };
}

export const authService = {
  async login(payload: LoginPayload): Promise<LoginResponse> {
    const res = await api.post('/auth/login', payload);
    return res.data.data;
  },

  async logout(): Promise<void> {
    await api.post('/auth/logout');
  },

  async logoutAll(): Promise<void> {
    await api.delete('/auth/logout-all');
  },

  async getMe() {
    const res = await api.get('/auth/me');
    return res.data.data;
  },
};
