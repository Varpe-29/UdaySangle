// src/services/complaints.service.ts
import api from '@/lib/api';

export const complaintsService = {
  async getAll(params?: Record<string, any>) {
    const res = await api.get('/complaints', { params });
    return res.data.data;
  },
  async getOne(id: string) {
    const res = await api.get(`/complaints/${id}`);
    return res.data.data;
  },
  async updateStatus(id: string, status: string) {
    const res = await api.patch(`/complaints/${id}/status`, { status });
    return res.data.data;
  },
  async addEntry(id: string, note: string) {
    const res = await api.post(`/complaints/${id}/entries`, { note });
    return res.data.data;
  },
  async remove(id: string) {
    const res = await api.delete(`/complaints/${id}`);
    return res.data.data;
  },
  async submitPublic(formData: FormData) {
    const res = await api.post('/complaints', formData, {
      headers: { 'Content-Type': 'multipart/form-data' },
    });
    return res.data.data;
  },
};

// src/services/appointments.service.ts
export const appointmentsService = {
  async getAll(params?: Record<string, any>) {
    const res = await api.get('/appointments', { params });
    return res.data.data;
  },
  async getOne(id: string) {
    const res = await api.get(`/appointments/${id}`);
    return res.data.data;
  },
  async updateStatus(id: string, status: string, notes?: string) {
    const res = await api.patch(`/appointments/${id}/status`, { status, notes });
    return res.data.data;
  },
  async remove(id: string) {
    const res = await api.delete(`/appointments/${id}`);
    return res.data.data;
  },
  async submitPublic(formData: FormData) {
    const res = await api.post('/appointments', formData, {
      headers: { 'Content-Type': 'multipart/form-data' },
    });
    return res.data.data;
  },
  async getStats() {
    const res = await api.get('/appointments/stats/summary');
    return res.data.data;
  },
};

// src/services/notices.service.ts
export const noticesService = {
  async getAll() {
    const res = await api.get('/notices');
    return res.data.data;
  },
  async create(formData: FormData) {
    const res = await api.post('/notices', formData, {
      headers: { 'Content-Type': 'multipart/form-data' },
    });
    return res.data.data;
  },
  async remove(id: string) {
    const res = await api.delete(`/notices/${id}`);
    return res.data.data;
  },
};

// src/services/letters.service.ts
export const lettersService = {
  async getAll() {
    const res = await api.get('/letters');
    return res.data.data;
  },
  async create(formData: FormData) {
    const res = await api.post('/letters', formData, {
      headers: { 'Content-Type': 'multipart/form-data' },
    });
    return res.data.data;
  },
  async remove(id: string) {
    const res = await api.delete(`/letters/${id}`);
    return res.data.data;
  },
};

// src/services/admin.service.ts
export const adminService = {
  async getAnalytics() {
    const res = await api.get('/admin/analytics');
    return res.data.data;
  },
  async getUsers(params?: Record<string, any>) {
    const res = await api.get('/admin/users', { params });
    return res.data.data;
  },
  async createUser(data: Record<string, any>) {
    const res = await api.post('/admin/users', data);
    return res.data.data;
  },
  async updateUserRole(id: string, role: string) {
    const res = await api.patch(`/admin/users/${id}/role`, { role });
    return res.data.data;
  },
  async toggleUserLock(id: string) {
    const res = await api.patch(`/admin/users/${id}/toggle-lock`);
    return res.data.data;
  },
  async deleteUser(id: string) {
    const res = await api.delete(`/admin/users/${id}`);
    return res.data.data;
  },
  async getActivityLogs(params?: Record<string, any>) {
    const res = await api.get('/admin/activity-logs', { params });
    return res.data.data;
  },
};
