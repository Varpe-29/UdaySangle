// src/validations/auth.schema.ts
import { z } from 'zod';

export const loginSchema = z.object({
  username: z
    .string()
    .min(1, 'Username is required')
    .max(50, 'Username too long')
    .trim(),
  password: z
    .string()
    .min(6, 'Password must be at least 6 characters')
    .max(100, 'Password too long'),
});

export type LoginSchema = z.infer<typeof loginSchema>;

// src/validations/complaint.schema.ts
export const complaintSchema = z.object({
  full_name: z.string().min(2, 'Full name required').max(100).trim(),
  mobile: z.string().regex(/^\d{10}$/, 'Enter valid 10-digit mobile number'),
  area: z.string().min(2, 'Area required').max(200).trim(),
  subject: z.string().min(3, 'Subject required').max(200).trim(),
  details: z.string().min(10, 'Please provide more details').max(2000).trim(),
  date: z.string().min(1, 'Date is required'),
});
export type ComplaintSchema = z.infer<typeof complaintSchema>;

// src/validations/appointment.schema.ts
export const appointmentSchema = z.object({
  full_name: z.string().min(2, 'Full name required').max(100).trim(),
  mobile: z.string().regex(/^\d{10}$/, 'Enter valid 10-digit mobile number'),
  area: z.string().min(2, 'Area required').max(200).trim(),
  purpose: z.string().min(10, 'Please describe the purpose').max(1000).trim(),
  date: z.string().min(1, 'Date is required'),
  time: z.string().min(1, 'Time is required'),
});
export type AppointmentSchema = z.infer<typeof appointmentSchema>;
